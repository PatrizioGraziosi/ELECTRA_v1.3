% The scattering parameters 

% RELEVANT SCATTERING for ZrCoSb valence band
% ADP_IVS (both intra- and inter-valley) and ODP_Npolar (both intra- and
% inter-valley)

%----------- PHONONS ---------
rho_mass_density=   7.23*1e-3/(1e-2)^3; % kg/m^3   from https://materialsproject.org/materials/mp-924130/
K_bulk_modulus = 122e9; % Pa
G_shear_modulus = 68e9; % Pa
sl = sqrt((K_bulk_modulus+4/3*G_shear_modulus)/rho_mass_density);  % m/s , elasticity theory
st = sqrt(G_shear_modulus/rho_mass_density);               % m/s , elasticity theory
us_sound_vel=1/3*sl+2/3*st;               % m/s   Ottaviani 1975

% ------- for electrons ------------------
D_adp_e=0.7; % eV, DOI: 10.1038/s41467-018-03866-w

D_odp_e= 2.3e10; % eV/m, DOI: 10.1038/s41467-018-03866-w,  multiplied by 1/5 BZ


% ------- for holes ------------------
D_adp_h=0.2; % eV, DOI: 10.1038/s41467-018-03866-w
% 
D_odp_h= 0.9e10; % eV/m, DOI: 10.1038/s41467-018-03866-w, multiplied by 1/5 BZ




hbar_w_odp= 0.034 ; %eV, 1https://materialsproject.org/materials/mp-924130/, from the centre in the LO phonons DOS, ~275 cm-1
Delta_Efi_odp=0;
Z_f_adp=1; % number of final available valleys
Z_f_odp=1; % to be defined as a row for every scattering mechanism, in any row an element for each available band

hbar_w_pop=0.035; % eV, https://materialsproject.org/materials/mp-924130/, assumed by us at the centre of the highest LO DOS

% ------- Coulomb scattering - screened  -------
k_s=22.92; % from Zhou (DOI: 10.1038/s41467-018-03866-w) private communication
k_inf=5; %  F.G. Aliev et al. Zh. Eksp. Teor. Fiz. 47 (t988) t5l
%LD=sqrt(eps_0*(eps_wire/eps_0)*kB*T/q0^2); % still need to divide by n0 in the sqrt
Z_i = 1; % ionized impurity charge


