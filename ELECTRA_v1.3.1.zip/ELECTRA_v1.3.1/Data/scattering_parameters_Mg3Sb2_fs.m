% The scattering parameters 

% RELEVANT SCATTERING for TiCoSb valence band
% ADP_IVS (both intra- and inter-valley) and ODP_Npolar (both intra- and
% inter-valley)

%----------- PHONONS ---------
rho_mass_density =  4.02e3; % kg/m^3   https://materialsproject.org/materials/mp-2646/
% K_bulk_modulus = 42e9; % Pa
% G_shear_modulus = 19e9; % Pa
% sl = sqrt((K_bulk_modulus+4/3*G_shear_modulus)/rho_mass_density);  % m/s , elasticity theory
% st = sqrt(G_shear_modulus/rho_mass_density);               % m/s , elasticity theory
% us_sound_vel=1/3*sl+2/3*st;               % m/s   Ottaviani 1975
us_sound_vel = 2.587e3;       


% ------- for holes ------------------
D_adp_h = 5; % eV, DOI: 10.1038/s41467-018-03866-w
% 
D_odp_h = 2e10; % eV/m, DOI: 10.1038/s41467-018-03866-w, multiplied by 1/5 of theBZ



% ------- for electrons ------------------

D_adp_e = 6.4; % eV, DOI: 10.1038/s41467-018-03866-w

D_odp_e = 2e10; % eV/m, DOI: 10.1038/s41467-018-03866-w, multiplied by 1/5 of theBZ


hbar_w_odp = 0.015 ; %eV, materialsproject.org/materials/mp-5967/  from the centre of the LO  phonons DOS
Delta_Efi_odp=0;
Z_f_adp=1; % number of final available valleys
Z_f_odp=1; % to be defined as a row for every scattering mechanism, in any row an element for each available band


D_ivs_e = [1.5e10,2e10,1.5e10,1e10,1.5e10]; % TA, LA, TA, LA, LO, TO

hbar_w_ivs_e = [0.03,0.03,0.03,0.03,0.03]; % TA, LA, TA, LA, LO, TO

% Delta_Efi_ivs=[0,0,0,0,0]; % TA, LA, TA, LA, LO, TO

Z_f_ivs = [2,1,5,5,5] /6 ; % number of final available valleys

hbar_w_pop=0.014; % eV, materialsproject.org/materials/mp-5967/  value in Gamma

k_s=26.7; % https://materialsproject.org/materials/mp-2646/
k_inf=14.2; %
Z_i = 1; % ionized impurity charge



