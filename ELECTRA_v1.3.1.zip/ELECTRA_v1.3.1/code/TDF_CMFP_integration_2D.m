% Copyright 2022 Patrizio Graziosi                                        %
% A creation of Patrizio Graziosi, written and developed by               %
% Patrizio Graziosi, patrizio.graziosi@cnr.it, during the                 %  
% Marie Curie - Individual Fellowships  GENESIS - project ID 788465       %
% Generic transport simulator for new generation thermoelectric materials %
%                                                                         %
% ----------------------------------------------------------------------- %
% This file is distributed under the terms of the GNU                     %
% General Public License.                                                 %
% ----------------------------------------------------------------------- %
%                                                                         %
% Please cite:                                                            %
% Journal of Applied Physics 126, 155701 (2019); 
% https://doi.org/10.1063/1.5116793
% when publishing results obtained  using the present  code               %
% ----------------------------------------------------------------------- %

function [sigma_CMFP, S_CMFP, PF_CMFP, ke_CMFP, mu_CMFP, n_carrier_CMFP  ] =   TDF_CMFP_integration_2D(E_array, T_array, TDF_CMFP, EF_matrix, DOS_tot, carriers)
                
 

EF_array = EF_matrix(:,1)';

FD=zeros(size(E_array,2),size(EF_array,2),size(T_array,2));
dfdE=zeros(size(E_array,2),size(EF_array,2),size(T_array,2));



integrand_sigma_xx=zeros(size(E_array,2),size(EF_array,2),size(T_array,2)); integrand_sigma_yy=zeros(size(E_array,2),size(EF_array,2),size(T_array,2));

integrand_S_xx=zeros(size(E_array,2),size(EF_array,2),size(T_array,2)); integrand_S_yy=zeros(size(E_array,2),size(EF_array,2),size(T_array,2));

integrand_k_e_xx=zeros(size(E_array,2),size(EF_array,2),size(T_array,2)); integrand_k_e_yy=zeros(size(E_array,2),size(EF_array,2),size(T_array,2));

integrand_n_carrier=zeros(size(E_array,2),size(EF_array,2),size(T_array,2));




q0=1.609e-19;             % [col]
kB=1.38e-23;              % [J/K]



sigma_CMFP = struct();
S_CMFP = struct();
PF_CMFP = struct();
mu_CMFP = struct();
ke_CMFP = struct();




for iEF = size(EF_array,2):-1:1
    for iT = size(T_array,2):-1:1
        EF_array = EF_matrix(:,iT)';

        FD(:,iEF,iT)=1./(exp((E_array-EF_array(iEF))./(kB*T_array(iT)/q0))+1);
        dfdE(:,iEF,iT)=-1./(kB*T_array(iT)/q0).*exp((E_array-EF_array(iEF))./(kB*T_array(iT)/q0)).*1./(exp((E_array-EF_array(iEF))./(kB*T_array(iT)/q0))+1).^2;

    end
end


if strcmp(carriers,'holes')
    carrier_sign = -1;
else 
    carrier_sign = 1;
end


    
% Definition of the TDFs
TDF_xx_CMFP = TDF_CMFP.xx; TDF_yy_CMFP = TDF_CMFP.yy;
         
  
% calculation of the TE coefficients
% 1) integrands functions, depend on the dimensionality


    for iT = size(T_array,2):-1:1
        EF_array = EF_matrix(:,iT)';
        for iEF = size(EF_array,2):-1:1                
                % charge carrier concentration in m^(-3), DOS_tot already
                % contains the 2/8pi^3, dSk and BZ_factor elements
                integrand_n_carrier(:,iEF,iT)=DOS_tot'.*FD(:,iEF,iT); 
                
%                 for iE=1:size(E_array,2) 
                    % integral arguments for electr. conductivity
                    integrand_sigma_xx(:,iEF,iT) = TDF_xx_CMFP(:) .* (dfdE(:,iEF,iT));
                    integrand_sigma_yy(:,iEF,iT) = TDF_yy_CMFP(:) .* (dfdE(:,iEF,iT));
                       
                    % charge carrier concentration in m^(-3), DOS_tot already
                    % contains the 2/8pi^3, dSk and BZ_factor elements
%                     integrand_n_carrier(iE,iEF,iT)=DOS_tot(iE)*FD(iE,iEF,iT); 
                    
                    % integral argument for Seebeck coeff.
                    integrand_S_xx(:,iEF,iT) = integrand_sigma_xx(:,iEF,iT) .* (E_array'-EF_array(iEF))*q0/(kB*T_array(iT));
                    integrand_S_yy(:,iEF,iT) = integrand_sigma_yy(:,iEF,iT) .* (E_array'-EF_array(iEF))*q0/(kB*T_array(iT));
                    
                    integrand_k_e_xx(:,iEF,iT) = integrand_sigma_xx(:,iEF,iT) .* ((E_array'-EF_array(iEF))*q0).^2;
                    integrand_k_e_yy(:,iEF,iT) = integrand_sigma_yy(:,iEF,iT) .* ((E_array'-EF_array(iEF))*q0).^2;
        end
    end
        

%
% calculation of the TE coefficients
% 2) integration over the energy

n_carrier_CMFP = squeeze(trapz(E_array,integrand_n_carrier,1));  % charge carrier concentration in m^(-3) 

sigma_xx_CMFP = squeeze(-q0*trapz(E_array,integrand_sigma_xx,1)); % integral over the Energy, first dimension
sigma_yy_CMFP = squeeze(-q0*trapz(E_array,integrand_sigma_yy,1));

sigma_average_CMFP=(sigma_xx_CMFP+sigma_yy_CMFP)/2;


mu_xx_CMFP=sigma_xx_CMFP./n_carrier_CMFP/q0;
mu_yy_CMFP=sigma_yy_CMFP./n_carrier_CMFP/q0;

mu_average_CMFP=(mu_xx_CMFP+mu_yy_CMFP)/2;


%Seebeck coefficients
S_xx_CMFP = carrier_sign .* kB./sigma_xx_CMFP.* squeeze(trapz(E_array,integrand_S_xx,1));
S_yy_CMFP = carrier_sign .* kB./sigma_yy_CMFP.* squeeze(trapz(E_array,integrand_S_yy,1));

S_average_CMFP=(S_xx_CMFP+S_yy_CMFP)/2;

% Power Factor
PF_xx_CMFP = sigma_xx_CMFP .* S_xx_CMFP.^2;
PF_yy_CMFP = sigma_yy_CMFP .* S_yy_CMFP.^2;

PF_average_CMFP=(PF_xx_CMFP+PF_yy_CMFP)/2;

% electron thermal conductivity
k_e_xx_CMFP = -1./(q0*T_array) .*  squeeze(trapz(E_array,integrand_k_e_xx,1)) - sigma_xx_CMFP .* S_xx_CMFP.^2 .* T_array ;
k_e_yy_CMFP = -1./(q0*T_array) .*  squeeze(trapz(E_array,integrand_k_e_yy,1)) - sigma_yy_CMFP .* S_yy_CMFP.^2 .* T_array ;

k_e_average_CMFP = (k_e_xx_CMFP + k_e_yy_CMFP ) / 2;



% save into structures
sigma_CMFP.xx = sigma_xx_CMFP; sigma_CMFP.yy = sigma_yy_CMFP;
sigma_CMFP.average = sigma_average_CMFP;

mu_CMFP.xx = mu_xx_CMFP; mu_CMFP.yy = mu_yy_CMFP;
mu_CMFP.average = mu_average_CMFP;

S_CMFP.xx = S_xx_CMFP; S_CMFP.yy = S_yy_CMFP;
S_CMFP.average = S_average_CMFP;

PF_CMFP.xx = PF_xx_CMFP; PF_CMFP.yy = PF_yy_CMFP;
PF_CMFP.average = PF_average_CMFP;

ke_CMFP.xx = k_e_xx_CMFP; ke_CMFP.yy = k_e_yy_CMFP;
ke_CMFP.average = k_e_average_CMFP;

% ------------------------------------------------------------------------

end