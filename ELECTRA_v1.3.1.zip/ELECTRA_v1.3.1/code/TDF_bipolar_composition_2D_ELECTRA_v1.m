% Copyright 2022 Patrizio Graziosi                                        %
% A creation of Patrizio Graziosi, written and developed by               %
% Patrizio Graziosi, patrizio.graziosi@cnr.it, during the                 %
% Marie Curie - Individual Fellowships  GENESIS - project ID 788465       %
% Generic transport simulator for new generation thermoelectric materials %
%                                                                         %
% ----------------------------------------------------------------------- %
% This file is distributed under the terms of the GNU                     %
% General Public License.                                                 %
% ----------------------------------------------------------------------- %
%                                                                         %
% Please cite:                                                            %
% ACS Appl. Energy Mater. 2020, 3, 6, 5913–5926
% https://doi.org/10.1021/acsaem.0c00825
% when publishing results obtained  using the present  code               %
% ----------------------------------------------------------------------- %

% this code extracts the TE properties
% for now, inputs are DOS_tot(E,DOS(E)), TDF_tau_ij_tot(E,sigma_ij_tot(E))
% that is vi*vj*DOS, tau

% NOTE 
% on 08/05/2019 I added some lines to consider the EF shift imposing 
% that EF_array becomes the EF_matrix column that corresponds at each 
% temperature, and other lines to consider that the maximum EF can be in the gap


function [ TDF, TDF_ph, TDF_sep, MFP, MFP_ph, MFP_sep, tauE, tauE_ph, tauE_sep, tauE_IIS, DOS_tot, V_tot ] = ...
    TDF_bipolar_composition_2D_ELECTRA_v1( TDF_electron, TDF_ph_electron, TDF_sep_electron, ...
                MFP_electron, MFP_ph_electron, MFP_sep_electron, ...
                tauE_electron, tauE_ph_electron, tauE_sep_electron, tauE_IIS_electron, ...
                TDF_hole, TDF_ph_hole, TDF_sep_hole, ...
                MFP_hole, MFP_ph_hole, MFP_sep_hole, ...
                tauE_hole, tauE_ph_hole, tauE_sep_hole, tauE_IIS_hole, ...
                E_array, E_array_majority, E_array_minority, ...
                DOS_tot_majority, DOS_tot_minority, ...
                V_tot_majority, V_tot_minority, ...
                EF_matrix, minority_band_edge, WorkSpace4, negative_gap  ) %#codegen


if strcmp(negative_gap,'yes')
    disp(' The bandgap is negative, the material can be a metal or a semimetal ')
    disp(' ')
end

nE = size(E_array,2); 
nEF = size(EF_matrix,1);
% nEF_ph = size(EF_matrix_ph,1); % NOT used ?
nT = size(EF_matrix,2);



ADP = WorkSpace4.ADP ;                          % scattering instructions
ADP_IVS = WorkSpace4.ADP_IVS ;
Alloy = WorkSpace4.Alloy ;
ODP = WorkSpace4.ODP ;
POP = WorkSpace4.POP ;
screening_POP = WorkSpace4.screening_POP ;
IVS = WorkSpace4.IVS ;
IIS = WorkSpace4.IIS ;







% Initializations of the ovreall cmprehensive struct variables

    TDF=struct(); TDF_ph=struct(); TDF_sep=struct(); MFP=struct(); MFP_ph=struct(); MFP_sep=struct(); tauE=struct(); tauE_ph=struct(); tauE_sep=struct(); tauE_IIS=struct();
    
    % fields with the different bands
    TDF.xx = zeros(nE, nEF, nT ); TDF.yy = zeros(nE, nEF, nT ); 
    TDF.xy = zeros(nE, nEF, nT ); TDF.yx = zeros(nE, nEF, nT ); 
    MFP.x= zeros(nE, nEF, nT ); MFP.y = zeros(nE, nEF, nT );
    tauE.x = zeros(nE, nEF, nT ); tauE.y = zeros(nE, nEF, nT );
    tauE_IIS.x = zeros(nE, nEF, nT ); tauE_IIS.y = zeros(nE, nEF, nT );
    
    TDF_sep.ADP=struct(); TDF_sep.ODP=struct(); TDF_sep.POP=struct(); TDF_sep.IVS=struct(); TDF_sep.Alloy=struct();
    tauE_sep.ADP=struct(); tauE_sep.ODP=struct(); tauE_sep.POP=struct(); tauE_sep.IVS=struct(); tauE_sep.Alloy=struct();
    MFP_sep.ADP=struct(); MFP_sep.ODP=struct(); MFP_sep.POP=struct(); MFP_sep.IVS=struct(); MFP_sep.Alloy=struct();
    
    TDF_sep.ADP.xx = zeros( nE, nT ); TDF_sep.ADP.yy = zeros( nE, nT );
    TDF_sep.ADP.xy = zeros( nE, nT ); TDF_sep.ADP.yx = zeros( nE, nT );
    TDF_sep.ODP.xx = zeros( nE, nT ); TDF_sep.ODP.yy = zeros( nE, nT );
    TDF_sep.ODP.xy = zeros( nE, nT ); TDF_sep.ODP.yx = zeros( nE, nT ); 
    TDF_sep.IVS.xy = zeros( nE, nT ); TDF_sep.IVS.yx = zeros( nE, nT ); 
    TDF_sep.Alloy.xx = zeros( nE, nT ); TDF_sep.Alloy.yy = zeros( nE, nT ); 
    TDF_sep.Alloy.xy = zeros( nE, nT ); TDF_sep.Alloy.yx = zeros( nE, nT );
    
    MFP_sep.ADP.x = zeros( nE, nT ); MFP_sep.ADP.y = zeros( nE, nT ); 
    MFP_sep.ODP.x = zeros( nE, nT ); MFP_sep.ODP.y = zeros( nE, nT ); 
    MFP_sep.IVS.x = zeros( nE, nT ); MFP_sep.IVS.y = zeros( nE, nT ); 
    MFP_sep.Alloy.x = zeros( nE, nT ); MFP_sep.Alloy.y = zeros( nE, nT );
    
    tauE_sep.ADP.x = zeros( nE, nT ); tauE_sep.ADP.y = zeros( nE, nT ); 
    tauE_sep.ODP.x = zeros( nE, nT ); tauE_sep.ODP.y = zeros( nE, nT ); 
    tauE_sep.IVS.x = zeros( nE, nT ); tauE_sep.IVS.y = zeros( nE, nT );
    tauE_sep.Alloy.x = zeros( nE, nT ); tauE_sep.Alloy.y = zeros( nE, nT ); 
    
    
    if strcmp(POP,'yes') && strcmp(screening_POP,'yes')
        
        TDF_sep.POP.xx = zeros(nE, nEF, nT ); TDF_sep.POP.yy = zeros(nE, nEF, nT );
        TDF_sep.POP.xy = zeros(nE, nEF, nT ); TDF_sep.POP.yx = zeros(nE, nEF, nT );
        MFP_sep.POP.x = zeros(nE, nEF, nT ); MFP_sep.POP.y = zeros(nE, nEF, nT );
        tauE_sep.POP.x = zeros(nE, nEF, nT ); tauE_sep.POP.y = zeros(nE, nEF, nT );
                       
        TDF_ph.xx = zeros(nE, nEF, nT ); TDF_ph.yy = zeros(nE, nEF, nT ); 
        TDF_ph.xy = zeros(nE, nEF, nT ); TDF_ph.yx = zeros(nE, nEF, nT );
        MFP_ph.x = zeros(nE, nEF, nT ); MFP_ph.y = zeros(nE, nEF, nT ); 
        tauE_ph.x = zeros(nE, nEF, nT ); tauE_ph.y = zeros(nE, nEF, nT );
           
    else
        
        TDF_sep.POP.xx = zeros( nE, nT ); TDF_sep.POP.yy = zeros( nE, nT );
        TDF_sep.POP.xy = zeros( nE, nT ); TDF_sep.POP.yx = zeros( nE, nT );
        MFP_sep.POP.x = zeros( nE, nT ); MFP_sep.POP.y = zeros( nE, nT ); 
        tauE_sep.POP.x = zeros( nE, nT ); tauE_sep.POP.y = zeros( nE, nT ); 
        
        TDF_ph.xx = zeros( nE, nT ); TDF_ph.yy = zeros( nE, nT );
        TDF_ph.xy = zeros( nE, nT ); TDF_ph.yx = zeros( nE, nT );
        MFP_ph.x = zeros( nE, nT ); MFP_ph.y = zeros( nE, nT );
        tauE_ph.x = zeros( nE, nT ); tauE_ph.y = zeros( nE, nT );
       
    end
    
    TDF_xx=zeros(size(E_array,2),size(EF_matrix,1),size(EF_matrix,2)); TDF_yy=zeros(size(E_array,2),size(EF_matrix,1),size(EF_matrix,2));
    TDF_xy=zeros(size(E_array,2),size(EF_matrix,1),size(EF_matrix,2)); TDF_yx=zeros(size(E_array,2),size(EF_matrix,1),size(EF_matrix,2)); 
    MFP_x=zeros(size(E_array,2),size(EF_matrix,1),size(EF_matrix,2)); MFP_y=zeros(size(E_array,2),size(EF_matrix,1),size(EF_matrix,2)); 
    tauE_x=zeros(size(E_array,2),size(EF_matrix,1),size(EF_matrix,2)); tauE_y=zeros(size(E_array,2),size(EF_matrix,1),size(EF_matrix,2));
    tauE_IIS_x=zeros(size(E_array,2),size(EF_matrix,1),size(EF_matrix,2)); tauE_IIS_y=zeros(size(E_array,2),size(EF_matrix,1),size(EF_matrix,2)); 
    
    DOS_tot = zeros(1,size(E_array,2)); V_tot = zeros(1,size(E_array,2),1);


    % conversion of the entered struct data into temp matrixes
    
    TDF_xx_majority = TDF_electron.xx;
    TDF_yy_majority = TDF_electron.yy;
    TDF_xy_majority = TDF_electron.xy;
    TDF_yx_majority = TDF_electron.yx;    
    
    TDF_xx_minority = TDF_hole.xx;
    TDF_yy_minority = TDF_hole.yy;
    TDF_xy_minority = TDF_hole.xy;
    TDF_yx_minority = TDF_hole.yx;
    
    MFP_x_majority = MFP_electron.x;
    MFP_y_majority = MFP_electron.y;
    
    MFP_x_minority = MFP_hole.x;
    MFP_y_minority = MFP_hole.y;
    
    tauE_x_majority = tauE_electron.x;
    tauE_y_majority = tauE_electron.y;
    
    tauE_x_minority = tauE_hole.x;
    tauE_y_minority = tauE_hole.y;
   
    
    if strcmp(IIS,'yes') || strcmp(Alloy,'yes')       
        tauE_IIS_x_majority = tauE_IIS_electron.x;
        tauE_IIS_y_majority = tauE_IIS_electron.y;

        tauE_IIS_x_minority = tauE_IIS_hole.x;
        tauE_IIS_y_minority = tauE_IIS_hole.y;
    end
    


    
    % composition of the Transport Density Functions TDF

    [~,pos_minority_band_edge] = min( abs(E_array - (-minority_band_edge)));
    [~,pos_majority_band_edge] = min( abs(E_array));
    
    [~,relative_pos_minority_band_edge] = min( abs(E_array_minority - minority_band_edge));
    [~,relative_pos_majority_band_edge] = min( abs(E_array_majority));
    
    if size(size(TDF_xx_minority,1):-1:relative_pos_minority_band_edge,2) < pos_minority_band_edge
        pos_minority_band_edge = pos_minority_band_edge-1;
    end
    if size(pos_majority_band_edge:size(TDF_xx,1),2) < size((relative_pos_majority_band_edge:size(TDF_xx_majority,1)),2) 
        relative_pos_majority_band_edge = relative_pos_majority_band_edge+1;
    end
    
    % additional control on 23 February 2022 in the 3D file
    diff_1 = length(1:pos_minority_band_edge) - length(size(TDF_xx_minority,1):-1:relative_pos_minority_band_edge);
    if diff_1 ~= 0 
        disp(' adjustment at the TDF composition level in TDF_bipolar_composition_ELECTRA_v1, line 218 ');
        relative_pos_minority_band_edge = relative_pos_minority_band_edge - diff_1;
    end
    diff_2 = length(pos_majority_band_edge:size(TDF_xx,1)) - length(relative_pos_majority_band_edge:size(TDF_xx_majority,1));
    if diff_2 ~= 0 
        disp(' adjustment at the TDF composition level in TDF_bipolar_composition_ELECTRA_v1, line 223 ');
        relative_pos_majority_band_edge = relative_pos_majority_band_edge - diff_2;
    end
    
    TDF_xx(1:pos_minority_band_edge,:,:) = TDF_xx_minority(size(TDF_xx_minority,1):-1:relative_pos_minority_band_edge,:,:);
    TDF_xx(pos_majority_band_edge:size(TDF_xx,1),:,:) = TDF_xx(pos_majority_band_edge:size(TDF_xx,1),:,:) + TDF_xx_majority((relative_pos_majority_band_edge:size(TDF_xx_majority,1)),:,:);
    
    TDF_yy(1:pos_minority_band_edge,:,:) = TDF_yy_minority(size(TDF_yy_minority,1):-1:relative_pos_minority_band_edge,:,:);
    TDF_yy(pos_majority_band_edge:size(TDF_yy,1),:,:) = TDF_yy(pos_majority_band_edge:size(TDF_xx,1),:,:) + TDF_yy_majority((relative_pos_majority_band_edge:size(TDF_yy_majority,1)),:,:);
        
    TDF_xy(1:pos_minority_band_edge,:,:) = TDF_xy_minority(size(TDF_xy_minority,1):-1:relative_pos_minority_band_edge,:,:);
    TDF_xy(pos_majority_band_edge:size(TDF_xy,1),:,:) = TDF_xy(pos_majority_band_edge:size(TDF_xx,1),:,:) + TDF_xy_majority((relative_pos_majority_band_edge:size(TDF_xy_majority,1)),:,:);
        
    TDF_yx(1:pos_minority_band_edge,:,:) = TDF_yx_minority(size(TDF_yx_minority,1):-1:relative_pos_minority_band_edge,:,:);
    TDF_yx(pos_majority_band_edge:size(TDF_yx,1),:,:) = TDF_yx(pos_majority_band_edge:size(TDF_xx,1),:,:) + TDF_yx_majority((relative_pos_majority_band_edge:size(TDF_yx_majority,1)),:,:);
    
    DOS_tot(1:pos_minority_band_edge) = DOS_tot_minority(size(DOS_tot_minority,2):-1:relative_pos_minority_band_edge);
    DOS_tot(pos_majority_band_edge:size(DOS_tot,2)) = DOS_tot(pos_majority_band_edge:size(DOS_tot,2)) + DOS_tot_majority((relative_pos_majority_band_edge:size(TDF_xx_majority,1)));
    
    V_tot(1:pos_minority_band_edge) = V_tot_minority(size(V_tot_minority,2):-1:relative_pos_minority_band_edge);
    if strcmp(negative_gap,'yes')
        A = V_tot(pos_majority_band_edge:size(DOS_tot,2)); 
        B = V_tot_majority((relative_pos_majority_band_edge:size(TDF_xx_majority,1)));
        [na,ma] =  find( A );
        [nb,mb] =  find( B );
        C = A+B;
        C(intersect(ma,mb)) = ( A((intersect(ma,mb)))+B((intersect(ma,mb))) )/2 ;
        V_tot(pos_majority_band_edge:size(V_tot,2)) = C;
    else
        V_tot(pos_majority_band_edge:size(V_tot,2)) = V_tot_majority((relative_pos_majority_band_edge:size(TDF_xx_majority,1)));
    end
    
    
    % composing the other energy dependent quantities
    NNan = isnan(MFP_x_majority); MFP_x_majority(NNan)=0;
    NNan = isnan(MFP_y_minority); MFP_y_minority(NNan)=0;
    NNan = isnan(MFP_y_majority); MFP_y_majority(NNan)=0;
    NNan = isnan(tauE_x_minority); tauE_x_minority(NNan)=0;
    NNan = isnan(tauE_x_majority); tauE_x_majority(NNan)=0;
    NNan = isnan(MFP_x_minority); MFP_x_minority(NNan)=0;
    NNan = isnan(tauE_y_majority); tauE_y_majority(NNan)=0;
    NNan = isnan(tauE_y_minority); tauE_y_minority(NNan)=0;
    if strcmp(IIS,'yes')        
        NNan = isnan(tauE_IIS_x_majority); tauE_IIS_x_majority(NNan)=0;
        NNan = isnan(tauE_IIS_x_minority); tauE_IIS_x_minority(NNan)=0;
        NNan = isnan(tauE_IIS_y_minority); tauE_IIS_y_minority(NNan)=0;
        NNan = isnan(tauE_IIS_y_majority); tauE_IIS_y_majority(NNan)=0;
    end
    if strcmp(negative_gap,'yes')
        MFP_x(1:pos_minority_band_edge,:,:) = MFP_x_minority(size(MFP_x_minority,1):-1:relative_pos_minority_band_edge,:,:);      
        MFP_x(pos_majority_band_edge:size(MFP_x,1),:,:) = merge_ave( MFP_x(pos_majority_band_edge:size(MFP_y,1),:,:) , MFP_x_majority((relative_pos_majority_band_edge:size(MFP_x_majority,1)),:,:) );

        MFP_y(1:pos_minority_band_edge,:,:) = MFP_y_minority(size(MFP_y_minority,1):-1:relative_pos_minority_band_edge,:,:);
        MFP_y(pos_majority_band_edge:size(MFP_y,1),:,:) = merge_ave( MFP_y(pos_majority_band_edge:size(MFP_y,1),:,:) , MFP_y_majority((relative_pos_majority_band_edge:size(MFP_x_majority,1)),:,:) );

        tauE_x(1:pos_minority_band_edge,:,:) = tauE_x_minority(size(tauE_x_minority,1):-1:relative_pos_minority_band_edge,:,:);
        tauE_x(pos_majority_band_edge:size(tauE_x,1),:,:) = merge_ave(tauE_x(pos_majority_band_edge:size(tauE_x,1),:,:) , tauE_x_majority((relative_pos_majority_band_edge:size(tauE_x_majority,1)),:,:) );

        tauE_y(1:pos_minority_band_edge,:,:) = tauE_y_minority(size(tauE_y_minority,1):-1:relative_pos_minority_band_edge,:,:);
        tauE_y(pos_majority_band_edge:size(tauE_y,1),:,:) = merge_ave(tauE_y(pos_majority_band_edge:size(tauE_y,1),:,:) , tauE_y_majority((relative_pos_majority_band_edge:size(tauE_x_majority,1)),:,:) );

        
        if strcmp(IIS,'yes')
            tauE_IIS_x(1:pos_minority_band_edge,:,:) = tauE_IIS_x_minority(size(tauE_IIS_x_minority,1):-1:relative_pos_minority_band_edge,:,:);
            tauE_IIS_x(pos_majority_band_edge:size(tauE_IIS_x,1),:,:) = merge_ave( tauE_IIS_x(pos_majority_band_edge:size(tauE_IIS_x,1),:,:) , tauE_IIS_x_majority((relative_pos_majority_band_edge:size(tauE_IIS_x_majority,1)),:,:) );

            tauE_IIS_y(1:pos_minority_band_edge,:,:) = tauE_IIS_y_minority(size(tauE_IIS_y_minority,1):-1:relative_pos_minority_band_edge,:,:);
            tauE_IIS_y(pos_majority_band_edge:size(tauE_IIS_y,1),:,:) = merge_ave( tauE_IIS_y(pos_majority_band_edge:size(tauE_IIS_y,1),:,:) , tauE_IIS_y_majority((relative_pos_majority_band_edge:size(tauE_IIS_x_majority,1)),:,:) );

        end
        
    else
        MFP_x(1:pos_minority_band_edge,:,:) = MFP_x_minority(size(MFP_x_minority,1):-1:relative_pos_minority_band_edge,:,:);
        MFP_x(pos_majority_band_edge:size(MFP_x,1),:,:) = MFP_x(pos_majority_band_edge:size(MFP_x,1),:,:) + MFP_x_majority((relative_pos_majority_band_edge:size(MFP_x_majority,1)),:,:);

        MFP_y(1:pos_minority_band_edge,:,:) = MFP_y_minority(size(MFP_y_minority,1):-1:relative_pos_minority_band_edge,:,:);
        MFP_y(pos_majority_band_edge:size(MFP_y,1),:,:) = MFP_y(pos_majority_band_edge:size(MFP_y,1),:,:) + MFP_y_majority((relative_pos_majority_band_edge:size(MFP_x_majority,1)),:,:);

        tauE_x(1:pos_minority_band_edge,:,:) = tauE_x_minority(size(tauE_x_minority,1):-1:relative_pos_minority_band_edge,:,:);
        tauE_x(pos_majority_band_edge:size(tauE_x,1),:,:) = tauE_x(pos_majority_band_edge:size(tauE_x,1),:,:) + tauE_x_majority((relative_pos_majority_band_edge:size(tauE_x_majority,1)),:,:);

        tauE_y(1:pos_minority_band_edge,:,:) = tauE_y_minority(size(tauE_y_minority,1):-1:relative_pos_minority_band_edge,:,:);
        tauE_y(pos_majority_band_edge:size(tauE_y,1),:,:) = tauE_y(pos_majority_band_edge:size(tauE_y,1),:,:) + tauE_y_majority((relative_pos_majority_band_edge:size(tauE_x_majority,1)),:,:);


        if strcmp(IIS,'yes')
            tauE_IIS_x(1:pos_minority_band_edge,:,:) = tauE_IIS_x_minority(size(tauE_IIS_x_minority,1):-1:relative_pos_minority_band_edge,:,:);
            tauE_IIS_x(pos_majority_band_edge:size(tauE_IIS_x,1),:,:) = tauE_IIS_x(pos_majority_band_edge:size(tauE_IIS_x,1),:,:) + tauE_IIS_x_majority((relative_pos_majority_band_edge:size(tauE_IIS_x_majority,1)),:,:);

            tauE_IIS_y(1:pos_minority_band_edge,:,:) = tauE_IIS_y_minority(size(tauE_IIS_y_minority,1):-1:relative_pos_minority_band_edge,:,:);
            tauE_IIS_y(pos_majority_band_edge:size(tauE_IIS_y,1),:,:) = tauE_IIS_y(pos_majority_band_edge:size(tauE_IIS_y,1),:,:) + tauE_IIS_y_majority((relative_pos_majority_band_edge:size(tauE_IIS_x_majority,1)),:,:);
        end
    end
   
    
    TDF.xx = TDF_xx; TDF.xy = TDF_xy;
    TDF.yx = TDF_yx; TDF.yy = TDF_yy; 
    
    MFP.x = MFP_x; MFP.y = MFP_y; 
    tauE.x = tauE_x; tauE.y = tauE_y; 
    if strcmp(IIS,'yes')
        tauE_IIS.x = tauE_IIS_x; tauE_IIS.y = tauE_IIS_y;
    end    
    
    
    
    
    % ---------  ADP only---------------------------------------------
if strcmp(ADP,'yes') || strcmp(ADP_IVS,'yes')
    
    TDF_xx_ADP=zeros(size(E_array,2),size(EF_matrix,2)); TDF_yy_ADP=zeros(size(E_array,2),size(EF_matrix,2));
    TDF_xy_ADP=zeros(size(E_array,2),size(EF_matrix,2)); TDF_yx_ADP=zeros(size(E_array,2),size(EF_matrix,2)); 
    MFP_x_ADP=zeros(size(E_array,2),size(EF_matrix,2)); MFP_y_ADP=zeros(size(E_array,2),size(EF_matrix,2)); 
    tauE_x_ADP=zeros(size(E_array,2),size(EF_matrix,2)); tauE_y_ADP=zeros(size(E_array,2),size(EF_matrix,2)); 

    TDF_xx_ADP_majority = TDF_sep_electron.ADP.xx;
    TDF_yy_ADP_majority = TDF_sep_electron.ADP.yy;
    TDF_xy_ADP_majority = TDF_sep_electron.ADP.xy;
    TDF_yx_ADP_majority = TDF_sep_electron.ADP.yx;
    
    TDF_xx_ADP_minority = TDF_sep_hole.ADP.xx;
    TDF_yy_ADP_minority = TDF_sep_hole.ADP.yy;
    TDF_xy_ADP_minority = TDF_sep_hole.ADP.xy;
    TDF_yx_ADP_minority = TDF_sep_hole.ADP.yx;
    
    MFP_x_ADP_majority = MFP_sep_electron.ADP.x;
    MFP_y_ADP_majority = MFP_sep_electron.ADP.y;
    
    MFP_x_ADP_minority = MFP_sep_hole.ADP.x;
    MFP_y_ADP_minority = MFP_sep_hole.ADP.y;
    
    tauE_x_ADP_majority = tauE_sep_electron.ADP.x;
    tauE_y_ADP_majority = tauE_sep_electron.ADP.y;
    
    tauE_x_ADP_minority = tauE_sep_hole.ADP.x;
    tauE_y_ADP_minority = tauE_sep_hole.ADP.y;
    
    TDF_xx_ADP(1:pos_minority_band_edge,:) = TDF_xx_ADP_minority(size(TDF_xx_ADP_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_xx_ADP(pos_majority_band_edge:size(TDF_xx_ADP,1),:) = TDF_xx_ADP(pos_majority_band_edge:size(TDF_xx_ADP,1),:) + TDF_xx_ADP_majority((relative_pos_majority_band_edge:size(TDF_xx_ADP_majority,1)),:);

    TDF_yy_ADP(1:pos_minority_band_edge,:) = TDF_yy_ADP_minority(size(TDF_yy_ADP_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_yy_ADP(pos_majority_band_edge:size(TDF_yy_ADP,1),:) = TDF_yy_ADP(pos_majority_band_edge:size(TDF_yy_ADP,1),:) + TDF_yy_ADP_majority((relative_pos_majority_band_edge:size(TDF_xx_ADP_majority,1)),:);
        
    TDF_xy_ADP(1:pos_minority_band_edge,:) = TDF_xy_ADP_minority(size(TDF_xy_ADP_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_xy_ADP(pos_majority_band_edge:size(TDF_xy_ADP,1),:) = TDF_xy_ADP(pos_majority_band_edge:size(TDF_xy_ADP,1),:) + TDF_xy_ADP_majority((relative_pos_majority_band_edge:size(TDF_xy_ADP_majority,1)),:);

    TDF_yx_ADP(1:pos_minority_band_edge,:) = TDF_yx_ADP_minority(size(TDF_yx_ADP_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_yx_ADP(pos_majority_band_edge:size(TDF_yx_ADP,1),:) = TDF_yx_ADP(pos_majority_band_edge:size(TDF_yx_ADP,1),:) + TDF_yx_ADP_majority((relative_pos_majority_band_edge:size(TDF_yx_ADP_majority,1)),:);
        
    
    % composing the other energy dependent quantities
    NNan = isnan(MFP_x_ADP_majority); MFP_x_ADP_majority(NNan)=0;
    NNan = isnan(MFP_y_ADP_minority); MFP_y_ADP_minority(NNan)=0;
    NNan = isnan(MFP_y_ADP_majority); MFP_y_ADP_majority(NNan)=0;
    NNan = isnan(tauE_x_ADP_minority); tauE_x_ADP_minority(NNan)=0;
    NNan = isnan(tauE_x_ADP_majority); tauE_x_ADP_majority(NNan)=0;
    NNan = isnan(MFP_x_ADP_minority); MFP_x_ADP_minority(NNan)=0;
    NNan = isnan(tauE_y_ADP_majority); tauE_y_ADP_majority(NNan)=0;
    NNan = isnan(tauE_y_ADP_minority); tauE_y_ADP_minority(NNan)=0;
    if strcmp(negative_gap,'yes')
        MFP_x_ADP(1:pos_minority_band_edge,:) = MFP_x_ADP_minority(size(MFP_x_ADP_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_x_ADP(pos_majority_band_edge:size(MFP_x_ADP,1),:) = merge_ave( MFP_x_ADP(pos_majority_band_edge:size(MFP_x_ADP,1),:) , MFP_x_ADP_majority((relative_pos_majority_band_edge:size(MFP_x_ADP_majority,1)),:) );

        MFP_y_ADP(1:pos_minority_band_edge,:) = MFP_y_ADP_minority(size(MFP_y_ADP_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_y_ADP(pos_majority_band_edge:size(MFP_y_ADP,1),:) = merge_ave(MFP_y_ADP(pos_majority_band_edge:size(MFP_y_ADP,1),:) , MFP_y_ADP_majority((relative_pos_majority_band_edge:size(MFP_x_ADP_majority,1)),:) );

        tauE_x_ADP(1:pos_minority_band_edge,:) = tauE_x_ADP_minority(size(tauE_x_ADP_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_x_ADP(pos_majority_band_edge:size(tauE_x_ADP,1),:) = merge_ave(tauE_x_ADP(pos_majority_band_edge:size(tauE_x_ADP,1),:) , tauE_x_ADP_majority((relative_pos_majority_band_edge:size(tauE_x_ADP_majority,1)),:) );

        tauE_y_ADP(1:pos_minority_band_edge,:) = tauE_y_ADP_minority(size(tauE_y_ADP_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_y_ADP(pos_majority_band_edge:size(tauE_y_ADP,1),:) = merge_ave(tauE_y_ADP(pos_majority_band_edge:size(tauE_y_ADP,1),:) , tauE_y_ADP_majority((relative_pos_majority_band_edge:size(tauE_x_ADP_majority,1)),:) );

    else
        MFP_x_ADP(1:pos_minority_band_edge,:) = MFP_x_ADP_minority(size(MFP_x_ADP_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_x_ADP(pos_majority_band_edge:size(MFP_x_ADP,1),:) = MFP_x_ADP(pos_majority_band_edge:size(MFP_x_ADP,1),:) + MFP_x_ADP_majority((relative_pos_majority_band_edge:size(MFP_x_ADP_majority,1)),:);

        MFP_y_ADP(1:pos_minority_band_edge,:) = MFP_y_ADP_minority(size(MFP_y_ADP_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_y_ADP(pos_majority_band_edge:size(MFP_y_ADP,1),:) = MFP_y_ADP(pos_majority_band_edge:size(MFP_y_ADP,1),:) + MFP_y_ADP_majority((relative_pos_majority_band_edge:size(MFP_x_ADP_majority,1)),:);

        tauE_x_ADP(1:pos_minority_band_edge,:) = tauE_x_ADP_minority(size(tauE_x_ADP_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_x_ADP(pos_majority_band_edge:size(tauE_x_ADP,1),:) = tauE_x_ADP(pos_majority_band_edge:size(tauE_x_ADP,1),:) + tauE_x_ADP_majority((relative_pos_majority_band_edge:size(tauE_x_ADP_majority,1)),:);

        tauE_y_ADP(1:pos_minority_band_edge,:) = tauE_y_ADP_minority(size(tauE_y_ADP_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_y_ADP(pos_majority_band_edge:size(tauE_y_ADP,1),:) = tauE_y_ADP(pos_majority_band_edge:size(tauE_y_ADP,1),:) + tauE_y_ADP_majority((relative_pos_majority_band_edge:size(tauE_x_ADP_majority,1)),:);
    end
        
    
    TDF_sep.ADP.xx = TDF_xx_ADP; TDF_sep.ADP.xy = TDF_xy_ADP; 
    TDF_sep.ADP.yx = TDF_yx_ADP; TDF_sep.ADP.yy = TDF_yy_ADP;
    
    MFP_sep.ADP.x = MFP_x_ADP; MFP_sep.ADP.y = MFP_y_ADP; 
    tauE_sep.ADP.x = tauE_x_ADP; tauE_sep.ADP.y = tauE_y_ADP;     
    
end
    
    % ---------  ODP only---------------------------------------------
if strcmp(ODP,'yes') 
    
    TDF_xx_ODP=zeros(size(E_array,2),size(EF_matrix,2)); TDF_yy_ODP=zeros(size(E_array,2),size(EF_matrix,2)); 
    TDF_xy_ODP=zeros(size(E_array,2),size(EF_matrix,2)); TDF_yx_ODP=zeros(size(E_array,2),size(EF_matrix,2));
    MFP_x_ODP=zeros(size(E_array,2),size(EF_matrix,2)); MFP_y_ODP=zeros(size(E_array,2),size(EF_matrix,2));
    tauE_x_ODP=zeros(size(E_array,2),size(EF_matrix,2)); tauE_y_ODP=zeros(size(E_array,2),size(EF_matrix,2));

    TDF_xx_ODP_majority = TDF_sep_electron.ODP.xx;
    TDF_yy_ODP_majority = TDF_sep_electron.ODP.yy;
    TDF_xy_ODP_majority = TDF_sep_electron.ODP.xy;
    TDF_yx_ODP_majority = TDF_sep_electron.ODP.yx;
    
    TDF_xx_ODP_minority = TDF_sep_hole.ODP.xx;
    TDF_yy_ODP_minority = TDF_sep_hole.ODP.yy;
    TDF_xy_ODP_minority = TDF_sep_hole.ODP.xy;
    TDF_yx_ODP_minority = TDF_sep_hole.ODP.yx;
    
    MFP_x_ODP_majority = MFP_sep_electron.ODP.x;
    MFP_y_ODP_majority = MFP_sep_electron.ODP.y;
    
    MFP_x_ODP_minority = MFP_sep_hole.ODP.x;
    MFP_y_ODP_minority = MFP_sep_hole.ODP.y;
    
    tauE_x_ODP_majority = tauE_sep_electron.ODP.x;
    tauE_y_ODP_majority = tauE_sep_electron.ODP.y;
    
    tauE_x_ODP_minority = tauE_sep_hole.ODP.x;
    tauE_y_ODP_minority = tauE_sep_hole.ODP.y;
    
    TDF_xx_ODP(1:pos_minority_band_edge,:) = TDF_xx_ODP_minority(size(TDF_xx_ODP_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_xx_ODP(pos_majority_band_edge:size(TDF_xx_ODP,1),:) = TDF_xx_ODP(pos_majority_band_edge:size(TDF_xx_ODP,1),:) + TDF_xx_ODP_majority((relative_pos_majority_band_edge:size(TDF_xx_ODP_majority,1)),:);
    
    TDF_yy_ODP(1:pos_minority_band_edge,:) = TDF_yy_ODP_minority(size(TDF_yy_ODP_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_yy_ODP(pos_majority_band_edge:size(TDF_yy_ODP,1),:) = TDF_yy_ODP(pos_majority_band_edge:size(TDF_xx_ODP,1),:) + TDF_yy_ODP_majority((relative_pos_majority_band_edge:size(TDF_xx_ODP_majority,1)),:);
        
    TDF_xy_ODP(1:pos_minority_band_edge,:) = TDF_xy_ODP_minority(size(TDF_xy_ODP_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_xy_ODP(pos_majority_band_edge:size(TDF_xy_ODP,1),:) = TDF_xy_ODP(pos_majority_band_edge:size(TDF_xx_ODP,1),:) + TDF_xy_ODP_majority((relative_pos_majority_band_edge:size(TDF_xy_ODP_majority,1)),:);
            
    TDF_yx_ODP(1:pos_minority_band_edge,:) = TDF_yx_ODP_minority(size(TDF_yx_ODP_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_yx_ODP(pos_majority_band_edge:size(TDF_yx_ODP,1),:) = TDF_yx_ODP(pos_majority_band_edge:size(TDF_xx_ODP,1),:) + TDF_yx_ODP_majority((relative_pos_majority_band_edge:size(TDF_yx_ODP_majority,1)),:);
        
    
    % composing the other energy dependent quantities
    NNan = isnan(MFP_x_ODP_majority); MFP_x_ODP_majority(NNan)=0;
    NNan = isnan(MFP_y_ODP_minority); MFP_y_ODP_minority(NNan)=0;
    NNan = isnan(MFP_y_ODP_majority); MFP_y_ODP_majority(NNan)=0;
    NNan = isnan(tauE_x_ODP_minority); tauE_x_ODP_minority(NNan)=0;
    NNan = isnan(tauE_x_ODP_majority); tauE_x_ODP_majority(NNan)=0;
    NNan = isnan(MFP_x_ODP_minority); MFP_x_ODP_minority(NNan)=0;
    NNan = isnan(tauE_y_ODP_majority); tauE_y_ODP_majority(NNan)=0;
    NNan = isnan(tauE_y_ODP_minority); tauE_y_ODP_minority(NNan)=0;
    if strcmp(negative_gap,'yes')
        MFP_x_ODP(1:pos_minority_band_edge,:) = MFP_x_ODP_minority(size(MFP_x_ODP_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_x_ODP(pos_majority_band_edge:size(MFP_x_ODP,1),:) = merge_ave( MFP_x_ODP(pos_majority_band_edge:size(MFP_x_ODP,1),:) , MFP_x_ODP_majority((relative_pos_majority_band_edge:size(MFP_x_ODP_majority,1)),:) );

        MFP_y_ODP(1:pos_minority_band_edge,:) = MFP_y_ODP_minority(size(MFP_y_ODP_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_y_ODP(pos_majority_band_edge:size(MFP_y_ODP,1),:) = merge_ave(MFP_y_ODP(pos_majority_band_edge:size(MFP_y_ODP,1),:) , MFP_y_ODP_majority((relative_pos_majority_band_edge:size(MFP_x_ODP_majority,1)),:) );

        tauE_x_ODP(1:pos_minority_band_edge,:) = tauE_x_ODP_minority(size(tauE_x_ODP_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_x_ODP(pos_majority_band_edge:size(tauE_x_ODP,1),:) = merge_ave(tauE_x_ODP(pos_majority_band_edge:size(tauE_x_ODP,1),:) , tauE_x_ODP_majority((relative_pos_majority_band_edge:size(tauE_x_ODP_majority,1)),:) );

        tauE_y_ODP(1:pos_minority_band_edge,:) = tauE_y_ODP_minority(size(tauE_y_ODP_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_y_ODP(pos_majority_band_edge:size(tauE_y_ODP,1),:) = merge_ave(tauE_y_ODP(pos_majority_band_edge:size(tauE_y_ODP,1),:) , tauE_y_ODP_majority((relative_pos_majority_band_edge:size(tauE_x_ODP_majority,1)),:) );

    else
        MFP_x_ODP(1:pos_minority_band_edge,:) = MFP_x_ODP_minority(size(MFP_x_ODP_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_x_ODP(pos_majority_band_edge:size(MFP_x_ODP,1),:) = MFP_x_ODP(pos_majority_band_edge:size(MFP_x_ODP,1),:) + MFP_x_ODP_majority((relative_pos_majority_band_edge:size(MFP_x_ODP_majority,1)),:);

        MFP_y_ODP(1:pos_minority_band_edge,:) = MFP_y_ODP_minority(size(MFP_y_ODP_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_y_ODP(pos_majority_band_edge:size(MFP_y_ODP,1),:) = MFP_y_ODP(pos_majority_band_edge:size(MFP_y_ODP,1),:) + MFP_y_ODP_majority((relative_pos_majority_band_edge:size(MFP_x_ODP_majority,1)),:);

        tauE_x_ODP(1:pos_minority_band_edge,:) = tauE_x_ODP_minority(size(tauE_x_ODP_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_x_ODP(pos_majority_band_edge:size(tauE_x_ODP,1),:) = tauE_x_ODP(pos_majority_band_edge:size(tauE_x_ODP,1),:) + tauE_x_ODP_majority((relative_pos_majority_band_edge:size(tauE_x_ODP_majority,1)),:);

        tauE_y_ODP(1:pos_minority_band_edge,:) = tauE_y_ODP_minority(size(tauE_y_ODP_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_y_ODP(pos_majority_band_edge:size(tauE_y_ODP,1),:) = tauE_y_ODP(pos_majority_band_edge:size(tauE_y_ODP,1),:) + tauE_y_ODP_majority((relative_pos_majority_band_edge:size(tauE_x_ODP_majority,1)),:);
    end
    
    TDF_sep.ODP.xx = TDF_xx_ODP; TDF_sep.ODP.xy = TDF_xy_ODP; 
    TDF_sep.ODP.yx = TDF_yx_ODP; TDF_sep.ODP.yy = TDF_yy_ODP;
    
    MFP_sep.ODP.x = MFP_x_ODP; MFP_sep.ODP.y = MFP_y_ODP; 
    tauE_sep.ODP.x = tauE_x_ODP; tauE_sep.ODP.y = tauE_y_ODP;     
    
end



    % ---------  IVS only---------------------------------------------
if strcmp(IVS,'yes')
    
    TDF_xx_IVS=zeros(size(E_array,2),size(EF_matrix,2)); TDF_yy_IVS=zeros(size(E_array,2),size(EF_matrix,2)); 
    TDF_xy_IVS=zeros(size(E_array,2),size(EF_matrix,2)); TDF_yx_IVS=zeros(size(E_array,2),size(EF_matrix,2)); 
    MFP_x_IVS=zeros(size(E_array,2),size(EF_matrix,2)); MFP_y_IVS=zeros(size(E_array,2),size(EF_matrix,2)); 
    tauE_x_IVS=zeros(size(E_array,2),size(EF_matrix,2)); tauE_y_IVS=zeros(size(E_array,2),size(EF_matrix,2)); 

    TDF_xx_IVS_majority = TDF_sep_electron.IVS.xx;
    TDF_yy_IVS_majority = TDF_sep_electron.IVS.yy;
    TDF_xy_IVS_majority = TDF_sep_electron.IVS.xy;
    TDF_yx_IVS_majority = TDF_sep_electron.IVS.yx;
    
    TDF_xx_IVS_minority = TDF_sep_hole.IVS.xx;
    TDF_yy_IVS_minority = TDF_sep_hole.IVS.yy;
    TDF_xy_IVS_minority = TDF_sep_hole.IVS.xy;
    TDF_yx_IVS_minority = TDF_sep_hole.IVS.yx;
    
    MFP_x_IVS_majority = MFP_sep_electron.IVS.x;
    MFP_y_IVS_majority = MFP_sep_electron.IVS.y;
    
    MFP_x_IVS_minority = MFP_sep_hole.IVS.x;
    MFP_y_IVS_minority = MFP_sep_hole.IVS.y;
    
    tauE_x_IVS_majority = tauE_sep_electron.IVS.x;
    tauE_y_IVS_majority = tauE_sep_electron.IVS.y;
    
    tauE_x_IVS_minority = tauE_sep_hole.IVS.x;
    tauE_y_IVS_minority = tauE_sep_hole.IVS.y;
    
    TDF_xx_IVS(1:pos_minority_band_edge,:) = TDF_xx_IVS_minority(size(TDF_xx_IVS_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_xx_IVS(pos_majority_band_edge:size(TDF_xx_IVS,1),:) = TDF_xx_IVS(pos_majority_band_edge:size(TDF_xx_IVS,1),:) + TDF_xx_IVS_majority((relative_pos_majority_band_edge:size(TDF_xx_IVS_majority,1)),:);
    
    TDF_yy_IVS(1:pos_minority_band_edge,:) = TDF_yy_IVS_minority(size(TDF_yy_IVS_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_yy_IVS(pos_majority_band_edge:size(TDF_yy_IVS,1),:) = TDF_yy_IVS(pos_majority_band_edge:size(TDF_yy_IVS,1),:) + TDF_yy_IVS_majority((relative_pos_majority_band_edge:size(TDF_yy_IVS_majority,1)),:);
        
    TDF_xy_IVS(1:pos_minority_band_edge,:) = TDF_xy_IVS_minority(size(TDF_xy_IVS_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_xy_IVS(pos_majority_band_edge:size(TDF_xy_IVS,1),:) = TDF_xy_IVS(pos_majority_band_edge:size(TDF_xy_IVS,1),:) + TDF_xy_IVS_majority((relative_pos_majority_band_edge:size(TDF_xy_IVS_majority,1)),:);
        
    TDF_yx_IVS(1:pos_minority_band_edge,:) = TDF_yx_IVS_minority(size(TDF_yx_IVS_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_yx_IVS(pos_majority_band_edge:size(TDF_yx_IVS,1),:) = TDF_yx_IVS(pos_majority_band_edge:size(TDF_yx_IVS,1),:) + TDF_yx_IVS_majority((relative_pos_majority_band_edge:size(TDF_yx_IVS_majority,1)),:);
        
    
    % composing the other energy dependent quantities
    NNan = isnan(MFP_x_IVS_majority); MFP_x_IVS_majority(NNan)=0;
    NNan = isnan(MFP_y_IVS_minority); MFP_y_IVS_minority(NNan)=0;
    NNan = isnan(MFP_y_IVS_majority); MFP_y_IVS_majority(NNan)=0;
    NNan = isnan(tauE_x_IVS_minority); tauE_x_IVS_minority(NNan)=0;
    NNan = isnan(tauE_x_IVS_majority); tauE_x_IVS_majority(NNan)=0;
    NNan = isnan(MFP_x_IVS_minority); MFP_x_IVS_minority(NNan)=0;
    NNan = isnan(tauE_y_IVS_majority); tauE_y_IVS_majority(NNan)=0;
    NNan = isnan(tauE_y_IVS_minority); tauE_y_IVS_minority(NNan)=0;
    if strcmp(negative_gap,'yes')
        MFP_x_IVS(1:pos_minority_band_edge,:) = MFP_x_IVS_minority(size(MFP_x_IVS_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_x_IVS(pos_majority_band_edge:size(MFP_x_IVS,1),:) = merge_ave( MFP_x_IVS(pos_majority_band_edge:size(MFP_x_IVS,1),:) , MFP_x_IVS_majority((relative_pos_majority_band_edge:size(MFP_x_IVS_majority,1)),:) );

        MFP_y_IVS(1:pos_minority_band_edge,:) = MFP_y_IVS_minority(size(MFP_y_IVS_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_y_IVS(pos_majority_band_edge:size(MFP_y_IVS,1),:) = merge_ave(MFP_y_IVS(pos_majority_band_edge:size(MFP_y_IVS,1),:) , MFP_y_IVS_majority((relative_pos_majority_band_edge:size(MFP_x_IVS_majority,1)),:) );


        tauE_x_IVS(1:pos_minority_band_edge,:) = tauE_x_IVS_minority(size(tauE_x_IVS_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_x_IVS(pos_majority_band_edge:size(tauE_x_IVS,1),:) = merge_ave(tauE_x_IVS(pos_majority_band_edge:size(tauE_x_IVS,1),:) , tauE_x_IVS_majority((relative_pos_majority_band_edge:size(tauE_x_IVS_majority,1)),:) );

        tauE_y_IVS(1:pos_minority_band_edge,:) = tauE_y_IVS_minority(size(tauE_y_IVS_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_y_IVS(pos_majority_band_edge:size(tauE_y_IVS,1),:) = merge_ave(tauE_y_IVS(pos_majority_band_edge:size(tauE_y_IVS,1),:) , tauE_y_IVS_majority((relative_pos_majority_band_edge:size(tauE_x_IVS_majority,1)),:) );
    else
        MFP_x_IVS(1:pos_minority_band_edge,:) = MFP_x_IVS_minority(size(MFP_x_IVS_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_x_IVS(pos_majority_band_edge:size(MFP_x_IVS,1),:) = MFP_x_IVS(pos_majority_band_edge:size(MFP_x_IVS,1),:)+ MFP_x_IVS_majority((relative_pos_majority_band_edge:size(MFP_x_IVS_majority,1)),:);

        MFP_y_IVS(1:pos_minority_band_edge,:) = MFP_y_IVS_minority(size(MFP_y_IVS_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_y_IVS(pos_majority_band_edge:size(MFP_y_IVS,1),:) = MFP_y_IVS(pos_majority_band_edge:size(MFP_y_IVS,1),:)+ MFP_y_IVS_majority((relative_pos_majority_band_edge:size(MFP_y_IVS_majority,1)),:);

        tauE_x_IVS(1:pos_minority_band_edge,:) = tauE_x_IVS_minority(size(tauE_x_IVS_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_x_IVS(pos_majority_band_edge:size(tauE_x_IVS,1),:) = tauE_x_IVS(pos_majority_band_edge:size(tauE_x_IVS,1),:) + tauE_x_IVS_majority((relative_pos_majority_band_edge:size(tauE_x_IVS_majority,1)),:);

        tauE_y_IVS(1:pos_minority_band_edge,:) = tauE_y_IVS_minority(size(tauE_y_IVS_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_y_IVS(pos_majority_band_edge:size(tauE_y_IVS,1),:) = tauE_y_IVS(pos_majority_band_edge:size(tauE_y_IVS,1),:) + tauE_y_IVS_majority((relative_pos_majority_band_edge:size(tauE_x_IVS_majority,1)),:);
    end
    
    TDF_sep.IVS.xx = TDF_xx_IVS; TDF_sep.IVS.xy = TDF_xy_IVS; 
    TDF_sep.IVS.yx = TDF_yx_IVS; TDF_sep.IVS.yy = TDF_yy_IVS;
    
    MFP_sep.IVS.x = MFP_x_IVS; MFP_sep.IVS.y = MFP_y_IVS;
    tauE_sep.IVS.x = tauE_x_IVS; tauE_sep.IVS.y = tauE_y_IVS; 
    
    
end

 % ---------  POP only---------------------------------------------
if strcmp(POP,'yes')
    
    if strcmp(POP,'yes') && strcmp(screening_POP,'no')
    
        TDF_xx_POP=zeros(size(E_array,2),size(EF_matrix,2)); TDF_yy_POP=zeros(size(E_array,2),size(EF_matrix,2)); 
        TDF_xy_POP=zeros(size(E_array,2),size(EF_matrix,2)); TDF_yx_POP=zeros(size(E_array,2),size(EF_matrix,2));
        MFP_x_POP=zeros(size(E_array,2),size(EF_matrix,2)); MFP_y_POP=zeros(size(E_array,2),size(EF_matrix,2));
        tauE_x_POP=zeros(size(E_array,2),size(EF_matrix,2)); tauE_y_POP=zeros(size(E_array,2),size(EF_matrix,2));

        TDF_xx_POP_majority = TDF_sep_electron.POP.xx;
        TDF_yy_POP_majority = TDF_sep_electron.POP.yy;
        TDF_xy_POP_majority = TDF_sep_electron.POP.xy;
        TDF_yx_POP_majority = TDF_sep_electron.POP.yx;

        TDF_xx_POP_minority = TDF_sep_hole.POP.xx;
        TDF_yy_POP_minority = TDF_sep_hole.POP.yy;
        TDF_xy_POP_minority = TDF_sep_hole.POP.xy;
        TDF_yx_POP_minority = TDF_sep_hole.POP.yx;

        MFP_x_POP_majority = MFP_sep_electron.POP.x;
        MFP_y_POP_majority = MFP_sep_electron.POP.y;

        MFP_x_POP_minority = MFP_sep_hole.POP.x;
        MFP_y_POP_minority = MFP_sep_hole.POP.y;

        tauE_x_POP_majority = tauE_sep_electron.POP.x;
        tauE_y_POP_majority = tauE_sep_electron.POP.y;

        tauE_x_POP_minority = tauE_sep_hole.POP.x;
        tauE_y_POP_minority = tauE_sep_hole.POP.y;

        TDF_xx_POP(1:pos_minority_band_edge,:) = TDF_xx_POP_minority(size(TDF_xx_POP_minority,1):-1:relative_pos_minority_band_edge,:);
        TDF_xx_POP(pos_majority_band_edge:size(TDF_xx_POP,1),:) = TDF_xx_POP(pos_majority_band_edge:size(TDF_xx_POP,1),:) + TDF_xx_POP_majority((relative_pos_majority_band_edge:size(TDF_xx_POP_majority,1)),:);

        TDF_yy_POP(1:pos_minority_band_edge,:) = TDF_yy_POP_minority(size(TDF_yy_POP_minority,1):-1:relative_pos_minority_band_edge,:);
        TDF_yy_POP(pos_majority_band_edge:size(TDF_yy_POP,1),:) = TDF_yy_POP(pos_majority_band_edge:size(TDF_xx_POP,1),:) + TDF_yy_POP_majority((relative_pos_majority_band_edge:size(TDF_xx_POP_majority,1)),:);

        TDF_xy_POP(1:pos_minority_band_edge,:) = TDF_xy_POP_minority(size(TDF_xy_POP_minority,1):-1:relative_pos_minority_band_edge,:);
        TDF_xy_POP(pos_majority_band_edge:size(TDF_xy_POP,1),:) = TDF_xy_POP(pos_majority_band_edge:size(TDF_xx_POP,1),:) + TDF_xy_POP_majority((relative_pos_majority_band_edge:size(TDF_xy_POP_majority,1)),:);

        TDF_yx_POP(1:pos_minority_band_edge,:) = TDF_yx_POP_minority(size(TDF_yx_POP_minority,1):-1:relative_pos_minority_band_edge,:);
        TDF_yx_POP(pos_majority_band_edge:size(TDF_yx_POP,1),:) = TDF_yx_POP(pos_majority_band_edge:size(TDF_xx_POP,1),:) + TDF_yx_POP_majority((relative_pos_majority_band_edge:size(TDF_yx_POP_majority,1)),:);


        % composing the other energy dependent quantities
        NNan = isnan(MFP_x_POP_majority); MFP_x_POP_majority(NNan)=0;
        NNan = isnan(MFP_y_POP_minority); MFP_y_POP_minority(NNan)=0;
        NNan = isnan(MFP_y_POP_majority); MFP_y_POP_majority(NNan)=0;
        NNan = isnan(tauE_x_POP_minority); tauE_x_POP_minority(NNan)=0;
        NNan = isnan(tauE_x_POP_majority); tauE_x_POP_majority(NNan)=0;
        NNan = isnan(MFP_x_POP_minority); MFP_x_POP_minority(NNan)=0;
        NNan = isnan(tauE_y_POP_majority); tauE_y_POP_majority(NNan)=0;
        NNan = isnan(tauE_y_POP_minority); tauE_y_POP_minority(NNan)=0;
        if strcmp(negative_gap,'yes')
            MFP_x_POP(1:pos_minority_band_edge,:) = MFP_x_POP_minority(size(MFP_x_POP_minority,1):-1:relative_pos_minority_band_edge,:);
            MFP_x_POP(pos_majority_band_edge:size(MFP_x_POP,1),:) = merge_ave( MFP_x_POP(pos_majority_band_edge:size(MFP_x_POP,1),:) , MFP_x_POP_majority((relative_pos_majority_band_edge:size(MFP_x_POP_majority,1)),:) );

            MFP_y_POP(1:pos_minority_band_edge,:) = MFP_y_POP_minority(size(MFP_y_POP_minority,1):-1:relative_pos_minority_band_edge,:);
            MFP_y_POP(pos_majority_band_edge:size(MFP_y_POP,1),:) = merge_ave(MFP_y_POP(pos_majority_band_edge:size(MFP_y_POP,1),:) , MFP_y_POP_majority((relative_pos_majority_band_edge:size(MFP_x_POP_majority,1)),:) );

            tauE_x_POP(1:pos_minority_band_edge,:) = tauE_x_POP_minority(size(tauE_x_POP_minority,1):-1:relative_pos_minority_band_edge,:);
            tauE_x_POP(pos_majority_band_edge:size(tauE_x_POP,1),:) = merge_ave(tauE_x_POP(pos_majority_band_edge:size(tauE_x_POP,1),:) , tauE_x_POP_majority((relative_pos_majority_band_edge:size(tauE_x_POP_majority,1)),:) );

            tauE_y_POP(1:pos_minority_band_edge,:) = tauE_y_POP_minority(size(tauE_y_POP_minority,1):-1:relative_pos_minority_band_edge,:);
            tauE_y_POP(pos_majority_band_edge:size(tauE_y_POP,1),:) = merge_ave(tauE_y_POP(pos_majority_band_edge:size(tauE_y_POP,1),:) , tauE_y_POP_majority((relative_pos_majority_band_edge:size(tauE_x_POP_majority,1)),:) );

        else
            MFP_x_POP(1:pos_minority_band_edge,:) = MFP_x_POP_minority(size(MFP_x_POP_minority,1):-1:relative_pos_minority_band_edge,:);
            MFP_x_POP(pos_majority_band_edge:size(MFP_x_POP,1),:) = MFP_x_POP(pos_majority_band_edge:size(MFP_x_POP,1),:) + MFP_x_POP_majority((relative_pos_majority_band_edge:size(MFP_x_POP_majority,1)),:);

            MFP_y_POP(1:pos_minority_band_edge,:) = MFP_y_POP_minority(size(MFP_y_POP_minority,1):-1:relative_pos_minority_band_edge,:);
            MFP_y_POP(pos_majority_band_edge:size(MFP_y_POP,1),:) = MFP_y_POP(pos_majority_band_edge:size(MFP_y_POP,1),:) + MFP_y_POP_majority((relative_pos_majority_band_edge:size(MFP_x_POP_majority,1)),:);

            tauE_x_POP(1:pos_minority_band_edge,:) = tauE_x_POP_minority(size(tauE_x_POP_minority,1):-1:relative_pos_minority_band_edge,:);
            tauE_x_POP(pos_majority_band_edge:size(tauE_x_POP,1),:) = tauE_x_POP(pos_majority_band_edge:size(tauE_x_POP,1),:) + tauE_x_POP_majority((relative_pos_majority_band_edge:size(tauE_x_POP_majority,1)),:);

            tauE_y_POP(1:pos_minority_band_edge,:) = tauE_y_POP_minority(size(tauE_y_POP_minority,1):-1:relative_pos_minority_band_edge,:);
            tauE_y_POP(pos_majority_band_edge:size(tauE_y_POP,1),:) = tauE_y_POP(pos_majority_band_edge:size(tauE_y_POP,1),:) + tauE_y_POP_majority((relative_pos_majority_band_edge:size(tauE_x_POP_majority,1)),:);

        end
    
    elseif strcmp(POP,'yes') && strcmp(screening_POP,'yes')
        
        TDF_xx_POP=zeros(nE, nEF, nT ); TDF_yy_POP=zeros(nE, nEF, nT ); 
        TDF_xy_POP=zeros(nE, nEF, nT ); TDF_yx_POP=zeros(nE, nEF, nT ); 
        MFP_x_POP=zeros(nE, nEF, nT ); MFP_y_POP=zeros(nE, nEF, nT ); 
        tauE_x_POP=zeros(nE, nEF, nT ); tauE_y_POP=zeros(nE, nEF, nT ); 

        TDF_xx_POP_majority = TDF_sep_electron.POP.xx;
        TDF_yy_POP_majority = TDF_sep_electron.POP.yy;
        TDF_xy_POP_majority = TDF_sep_electron.POP.xy;
        TDF_yx_POP_majority = TDF_sep_electron.POP.yx;

        TDF_xx_POP_minority = TDF_sep_hole.POP.xx;
        TDF_yy_POP_minority = TDF_sep_hole.POP.yy;
        TDF_xy_POP_minority = TDF_sep_hole.POP.xy;
        TDF_yx_POP_minority = TDF_sep_hole.POP.yx;

        MFP_x_POP_majority = MFP_sep_electron.POP.x;
        MFP_y_POP_majority = MFP_sep_electron.POP.y;

        MFP_x_POP_minority = MFP_sep_hole.POP.x;
        MFP_y_POP_minority = MFP_sep_hole.POP.y;

        tauE_x_POP_majority = tauE_sep_electron.POP.x;
        tauE_y_POP_majority = tauE_sep_electron.POP.y;

        tauE_x_POP_minority = tauE_sep_hole.POP.x;
        tauE_y_POP_minority = tauE_sep_hole.POP.y;

        TDF_xx_POP(1:pos_minority_band_edge,:,:) = TDF_xx_POP_minority(size(TDF_xx_POP_minority,1):-1:relative_pos_minority_band_edge,:,:);
        TDF_xx_POP(pos_majority_band_edge:size(TDF_xx_POP,1),:,:) = TDF_xx_POP(pos_majority_band_edge:size(TDF_xx_POP,1),:,:) + TDF_xx_POP_majority((relative_pos_majority_band_edge:size(TDF_xx_POP_majority,1)),:,:);

        TDF_yy_POP(1:pos_minority_band_edge,:,:) = TDF_yy_POP_minority(size(TDF_yy_POP_minority,1):-1:relative_pos_minority_band_edge,:,:);
        TDF_yy_POP(pos_majority_band_edge:size(TDF_yy_POP,1),:,:) = TDF_yy_POP(pos_majority_band_edge:size(TDF_xx_POP,1),:,:) + TDF_yy_POP_majority((relative_pos_majority_band_edge:size(TDF_xx_POP_majority,1)),:,:);

        TDF_xy_POP(1:pos_minority_band_edge,:,:) = TDF_xy_POP_minority(size(TDF_xy_POP_minority,1):-1:relative_pos_minority_band_edge,:,:);
        TDF_xy_POP(pos_majority_band_edge:size(TDF_xy_POP,1),:,:) = TDF_xy_POP(pos_majority_band_edge:size(TDF_xx_POP,1),:,:) + TDF_xy_POP_majority((relative_pos_majority_band_edge:size(TDF_xy_POP_majority,1)),:,:);

        TDF_yx_POP(1:pos_minority_band_edge,:,:) = TDF_yx_POP_minority(size(TDF_yx_POP_minority,1):-1:relative_pos_minority_band_edge,:,:);
        TDF_yx_POP(pos_majority_band_edge:size(TDF_yx_POP,1),:,:) = TDF_yx_POP(pos_majority_band_edge:size(TDF_xx_POP,1),:,:) + TDF_yx_POP_majority((relative_pos_majority_band_edge:size(TDF_yx_POP_majority,1)),:,:);
        


        % composing the other energy dependent quantities
        NNan = isnan(MFP_x_POP_majority); MFP_x_POP_majority(NNan)=0;
        NNan = isnan(MFP_y_POP_minority); MFP_y_POP_minority(NNan)=0;
        NNan = isnan(MFP_y_POP_majority); MFP_y_POP_majority(NNan)=0;
        NNan = isnan(tauE_x_POP_minority); tauE_x_POP_minority(NNan)=0;
        NNan = isnan(tauE_x_POP_majority); tauE_x_POP_majority(NNan)=0;
        NNan = isnan(MFP_x_POP_minority); MFP_x_POP_minority(NNan)=0;
        NNan = isnan(tauE_y_POP_majority); tauE_y_POP_majority(NNan)=0;
        NNan = isnan(tauE_y_POP_minority); tauE_y_POP_minority(NNan)=0;
        if strcmp(negative_gap,'yes')
            MFP_x_POP(1:pos_minority_band_edge,:,:) = MFP_x_POP_minority(size(MFP_x_POP_minority,1):-1:relative_pos_minority_band_edge,:,:);
            MFP_x_POP(pos_majority_band_edge:size(MFP_x_POP,1),:,:) = merge_ave( MFP_x_POP(pos_majority_band_edge:size(MFP_x_POP,1),:,:) , MFP_x_POP_majority((relative_pos_majority_band_edge:size(MFP_x_POP_majority,1)),:,:) );

            MFP_y_POP(1:pos_minority_band_edge,:,:) = MFP_y_POP_minority(size(MFP_y_POP_minority,1):-1:relative_pos_minority_band_edge,:,:);
            MFP_y_POP(pos_majority_band_edge:size(MFP_y_POP,1),:,:) = merge_ave(MFP_y_POP(pos_majority_band_edge:size(MFP_y_POP,1),:,:) , MFP_y_POP_majority((relative_pos_majority_band_edge:size(MFP_x_POP_majority,1)),:,:) );

            tauE_x_POP(1:pos_minority_band_edge,:,:) = tauE_x_POP_minority(size(tauE_x_POP_minority,1):-1:relative_pos_minority_band_edge,:,:);
            tauE_x_POP(pos_majority_band_edge:size(tauE_x_POP,1),:,:) = merge_ave(tauE_x_POP(pos_majority_band_edge:size(tauE_x_POP,1),:,:) , tauE_x_POP_majority((relative_pos_majority_band_edge:size(tauE_x_POP_majority,1)),:,:) );

            tauE_y_POP(1:pos_minority_band_edge,:,:) = tauE_y_POP_minority(size(tauE_y_POP_minority,1):-1:relative_pos_minority_band_edge,:,:);
            tauE_y_POP(pos_majority_band_edge:size(tauE_y_POP,1),:,:) = merge_ave(tauE_y_POP(pos_majority_band_edge:size(tauE_y_POP,1),:,:) , tauE_y_POP_majority((relative_pos_majority_band_edge:size(tauE_x_POP_majority,1)),:,:) );
        else            
            MFP_x_POP(1:pos_minority_band_edge,:,:) = MFP_x_POP_minority(size(MFP_x_POP_minority,1):-1:relative_pos_minority_band_edge,:,:);
            MFP_x_POP(pos_majority_band_edge:size(MFP_x_POP,1),:,:) = MFP_x_POP(pos_majority_band_edge:size(MFP_x_POP,1),:,:) + MFP_x_POP_majority((relative_pos_majority_band_edge:size(MFP_x_POP_majority,1)),:,:);

            MFP_y_POP(1:pos_minority_band_edge,:,:) = MFP_y_POP_minority(size(MFP_y_POP_minority,1):-1:relative_pos_minority_band_edge,:,:);
            MFP_y_POP(pos_majority_band_edge:size(MFP_y_POP,1),:,:) = MFP_y_POP(pos_majority_band_edge:size(MFP_y_POP,1),:,:) + MFP_y_POP_majority((relative_pos_majority_band_edge:size(MFP_x_POP_majority,1)),:,:);

            tauE_x_POP(1:pos_minority_band_edge,:,:) = tauE_x_POP_minority(size(tauE_x_POP_minority,1):-1:relative_pos_minority_band_edge,:,:);
            tauE_x_POP(pos_majority_band_edge:size(tauE_x_POP,1),:,:) = tauE_x_POP(pos_majority_band_edge:size(tauE_x_POP,1),:,:) + tauE_x_POP_majority((relative_pos_majority_band_edge:size(tauE_x_POP_majority,1)),:,:);

            tauE_y_POP(1:pos_minority_band_edge,:,:) = tauE_y_POP_minority(size(tauE_y_POP_minority,1):-1:relative_pos_minority_band_edge,:,:);
            tauE_y_POP(pos_majority_band_edge:size(tauE_y_POP,1),:,:) = tauE_y_POP(pos_majority_band_edge:size(tauE_y_POP,1),:,:) + tauE_y_POP_majority((relative_pos_majority_band_edge:size(tauE_x_POP_majority,1)),:,:);

        end
        
    end

    TDF_sep.POP.xx = TDF_xx_POP; TDF_sep.POP.xy = TDF_xy_POP; 
    TDF_sep.POP.yx = TDF_yx_POP; TDF_sep.POP.yy = TDF_yy_POP; 

    MFP_sep.POP.x = MFP_x_POP; MFP_sep.POP.y = MFP_y_POP; 
    tauE_sep.POP.x = tauE_x_POP; tauE_sep.POP.y = tauE_y_POP; 
    
end

 % ---------  Alloy only---------------------------------------------
if strcmp(Alloy,'yes')
    
    TDF_xx_Alloy=zeros(size(E_array,2),size(EF_matrix,2)); TDF_yy_Alloy=zeros(size(E_array,2),size(EF_matrix,2)); 
    TDF_xy_Alloy=zeros(size(E_array,2),size(EF_matrix,2)); TDF_yx_Alloy=zeros(size(E_array,2),size(EF_matrix,2)); 
    MFP_x_Alloy=zeros(size(E_array,2),size(EF_matrix,2)); MFP_y_Alloy=zeros(size(E_array,2),size(EF_matrix,2)); 
    tauE_x_Alloy=zeros(size(E_array,2),size(EF_matrix,2)); tauE_y_Alloy=zeros(size(E_array,2),size(EF_matrix,2));

    TDF_xx_Alloy_majority = TDF_sep_electron.Alloy.xx;
    TDF_yy_Alloy_majority = TDF_sep_electron.Alloy.yy;
    TDF_xy_Alloy_majority = TDF_sep_electron.Alloy.xy;
    TDF_yx_Alloy_majority = TDF_sep_electron.Alloy.yx;
    
    TDF_xx_Alloy_minority = TDF_sep_hole.Alloy.xx;
    TDF_yy_Alloy_minority = TDF_sep_hole.Alloy.yy;
    TDF_xy_Alloy_minority = TDF_sep_hole.Alloy.xy;
    TDF_yx_Alloy_minority = TDF_sep_hole.Alloy.yx;
    
    MFP_x_Alloy_majority = MFP_sep_electron.Alloy.x;
    MFP_y_Alloy_majority = MFP_sep_electron.Alloy.y;
    
    MFP_x_Alloy_minority = MFP_sep_hole.Alloy.x;
    MFP_y_Alloy_minority = MFP_sep_hole.Alloy.y;
    
    tauE_x_Alloy_majority = tauE_sep_electron.Alloy.x;
    tauE_y_Alloy_majority = tauE_sep_electron.Alloy.y;
    
    tauE_x_Alloy_minority = tauE_sep_hole.Alloy.x;
    tauE_y_Alloy_minority = tauE_sep_hole.Alloy.y;
    
    TDF_xx_Alloy(1:pos_minority_band_edge,:) = TDF_xx_Alloy_minority(size(TDF_xx_Alloy_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_xx_Alloy(pos_majority_band_edge:size(TDF_xx_Alloy,1),:) = TDF_xx_Alloy(pos_majority_band_edge:size(TDF_xx_Alloy,1),:) + TDF_xx_Alloy_majority((relative_pos_majority_band_edge:size(TDF_xx_Alloy_majority,1)),:);
    
    TDF_yy_Alloy(1:pos_minority_band_edge,:) = TDF_yy_Alloy_minority(size(TDF_yy_Alloy_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_yy_Alloy(pos_majority_band_edge:size(TDF_yy_Alloy,1),:) = TDF_yy_Alloy(pos_majority_band_edge:size(TDF_xx_Alloy,1),:) + TDF_yy_Alloy_majority((relative_pos_majority_band_edge:size(TDF_xx_Alloy_majority,1)),:);
        
    TDF_xy_Alloy(1:pos_minority_band_edge,:) = TDF_xy_Alloy_minority(size(TDF_xy_Alloy_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_xy_Alloy(pos_majority_band_edge:size(TDF_xy_Alloy,1),:) = TDF_xy_Alloy(pos_majority_band_edge:size(TDF_xx_Alloy,1),:) + TDF_xy_Alloy_majority((relative_pos_majority_band_edge:size(TDF_xy_Alloy_majority,1)),:);
    
    TDF_yx_Alloy(1:pos_minority_band_edge,:) = TDF_yx_Alloy_minority(size(TDF_yx_Alloy_minority,1):-1:relative_pos_minority_band_edge,:);
    TDF_yx_Alloy(pos_majority_band_edge:size(TDF_yx_Alloy,1),:) = TDF_yx_Alloy(pos_majority_band_edge:size(TDF_xx_Alloy,1),:) + TDF_yx_Alloy_majority((relative_pos_majority_band_edge:size(TDF_yx_Alloy_majority,1)),:);
    
    
    % composing the other energy dependent quantities
     NNan = isnan(MFP_x_Alloy_majority); MFP_x_Alloy_majority(NNan)=0;
    NNan = isnan(MFP_y_Alloy_minority); MFP_y_Alloy_minority(NNan)=0;
    NNan = isnan(MFP_y_Alloy_majority); MFP_y_Alloy_majority(NNan)=0;
    NNan = isnan(tauE_x_Alloy_minority); tauE_x_Alloy_minority(NNan)=0;
    NNan = isnan(tauE_x_Alloy_majority); tauE_x_Alloy_majority(NNan)=0;
    NNan = isnan(MFP_x_Alloy_minority); MFP_x_Alloy_minority(NNan)=0;
    NNan = isnan(tauE_y_Alloy_majority); tauE_y_Alloy_majority(NNan)=0;
    NNan = isnan(tauE_y_Alloy_minority); tauE_y_Alloy_minority(NNan)=0;
    if strcmp(negative_gap,'yes')
        MFP_x_Alloy(1:pos_minority_band_edge,:,:) = MFP_x_Alloy_minority(size(MFP_x_Alloy_minority,1):-1:relative_pos_minority_band_edge,:,:);
        MFP_x_Alloy(pos_majority_band_edge:size(MFP_x_Alloy,1),:,:) = merge_ave( MFP_x_Alloy(pos_majority_band_edge:size(MFP_x_Alloy,1),:,:) , MFP_x_Alloy_majority((relative_pos_majority_band_edge:size(MFP_x_Alloy_majority,1)),:,:) );

        MFP_y_Alloy(1:pos_minority_band_edge,:,:) = MFP_y_Alloy_minority(size(MFP_y_Alloy_minority,1):-1:relative_pos_minority_band_edge,:,:);
        MFP_y_Alloy(pos_majority_band_edge:size(MFP_y_Alloy,1),:,:) = merge_ave(MFP_y_Alloy(pos_majority_band_edge:size(MFP_y_Alloy,1),:,:) , MFP_y_Alloy_majority((relative_pos_majority_band_edge:size(MFP_x_Alloy_majority,1)),:,:) );

        tauE_x_Alloy(1:pos_minority_band_edge,:,:) = tauE_x_Alloy_minority(size(tauE_x_Alloy_minority,1):-1:relative_pos_minority_band_edge,:,:);
        tauE_x_Alloy(pos_majority_band_edge:size(tauE_x_Alloy,1),:,:) = merge_ave(tauE_x_Alloy(pos_majority_band_edge:size(tauE_x_Alloy,1),:,:) , tauE_x_Alloy_majority((relative_pos_majority_band_edge:size(tauE_x_Alloy_majority,1)),:,:) );

        tauE_y_Alloy(1:pos_minority_band_edge,:,:) = tauE_y_Alloy_minority(size(tauE_y_Alloy_minority,1):-1:relative_pos_minority_band_edge,:,:);
        tauE_y_Alloy(pos_majority_band_edge:size(tauE_y_Alloy,1),:,:) = merge_ave(tauE_y_Alloy(pos_majority_band_edge:size(tauE_y_Alloy,1),:,:) , tauE_y_Alloy_majority((relative_pos_majority_band_edge:size(tauE_x_Alloy_majority,1)),:,:) );
    else
        MFP_x_Alloy(1:pos_minority_band_edge,:) = MFP_x_Alloy_minority(size(MFP_x_Alloy_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_x_Alloy(pos_majority_band_edge:size(MFP_x_Alloy,1),:) = MFP_x_Alloy(pos_majority_band_edge:size(MFP_x_Alloy,1),:) + MFP_x_Alloy_majority((relative_pos_majority_band_edge:size(MFP_x_Alloy_majority,1)),:);

        MFP_y_Alloy(1:pos_minority_band_edge,:) = MFP_y_Alloy_minority(size(MFP_y_Alloy_minority,1):-1:relative_pos_minority_band_edge,:);
        MFP_y_Alloy(pos_majority_band_edge:size(MFP_y_Alloy,1),:) = MFP_y_Alloy(pos_majority_band_edge:size(MFP_y_Alloy,1),:) + MFP_y_Alloy_majority((relative_pos_majority_band_edge:size(MFP_x_Alloy_majority,1)),:);

        tauE_x_Alloy(1:pos_minority_band_edge,:) = tauE_x_Alloy_minority(size(tauE_x_Alloy_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_x_Alloy(pos_majority_band_edge:size(tauE_x_Alloy,1),:) = tauE_x_Alloy(pos_majority_band_edge:size(tauE_x_Alloy,1),:) + tauE_x_Alloy_majority((relative_pos_majority_band_edge:size(tauE_x_Alloy_majority,1)),:);

        tauE_y_Alloy(1:pos_minority_band_edge,:) = tauE_y_Alloy_minority(size(tauE_y_Alloy_minority,1):-1:relative_pos_minority_band_edge,:);
        tauE_y_Alloy(pos_majority_band_edge:size(tauE_y_Alloy,1),:) = tauE_y_Alloy(pos_majority_band_edge:size(tauE_y_Alloy,1),:) + tauE_y_Alloy_majority((relative_pos_majority_band_edge:size(tauE_x_Alloy_majority,1)),:);

    end
    
    
    TDF_sep.Alloy.xx = TDF_xx_Alloy; TDF_sep.Alloy.xy = TDF_xy_Alloy; 
    TDF_sep.Alloy.yx = TDF_yx_Alloy; TDF_sep.Alloy.yy = TDF_yy_Alloy; 
    
    MFP_sep.Alloy.x = MFP_x_Alloy; MFP_sep.Alloy.y = MFP_y_Alloy; 
    tauE_sep.Alloy.x = tauE_x_Alloy; tauE_sep.Alloy.y = tauE_y_Alloy;     
    
end
    


    if strcmp(IIS,'yes') || strcmp(Alloy,'yes') % Da spostare più giù alla fine, occhio a IIS, anche per POP
        
        TDF_xx_ph_majority = TDF_ph_electron.xx;
        TDF_yy_ph_majority = TDF_ph_electron.yy;
        TDF_xy_ph_majority = TDF_ph_electron.xy;
        TDF_yx_ph_majority = TDF_ph_electron.yx;

        TDF_xx_ph_minority = TDF_ph_hole.xx;
        TDF_yy_ph_minority = TDF_ph_hole.yy;
        TDF_xy_ph_minority = TDF_ph_hole.xy;
        TDF_yx_ph_minority = TDF_ph_hole.yx;
        
        MFP_x_ph_majority = MFP_ph_electron.x;
        MFP_y_ph_majority = MFP_ph_electron.y;
        tauE_x_ph_majority = tauE_ph_electron.x;
        tauE_y_ph_majority = tauE_ph_electron.y;
        
        MFP_x_ph_minority = MFP_ph_hole.x;
        MFP_y_ph_minority = MFP_ph_hole.y;
        tauE_x_ph_minority = tauE_ph_hole.x;
        tauE_y_ph_minority = tauE_ph_hole.y;
        
        
        if strcmp(POP,'yes') && strcmp(screening_POP,'yes')
            
            TDF_xx_ph=zeros(nE, nEF, nT ); TDF_yy_ph=zeros(nE, nEF, nT );
            TDF_xy_ph=zeros(nE, nEF, nT ); TDF_yx_ph=zeros(nE, nEF, nT );
            MFP_x_ph=zeros(nE, nEF, nT ); MFP_y_ph=zeros(nE, nEF, nT ); 
            tauE_x_ph=zeros(nE, nEF, nT ); tauE_y_ph=zeros(nE, nEF, nT ); 
            

            TDF_xx_ph(1:pos_minority_band_edge,:,:) = TDF_xx_ph_minority(size(TDF_xx_ph_minority,1):-1:relative_pos_minority_band_edge,:,:);
            TDF_xx_ph(pos_majority_band_edge:size(TDF_xx_ph,1),:,:) = TDF_xx_ph(pos_majority_band_edge:size(TDF_xx_ph,1),:,:) + TDF_xx_ph_majority((relative_pos_majority_band_edge:size(TDF_xx_ph_majority,1)),:,:);

            TDF_yy_ph(1:pos_minority_band_edge,:,:) = TDF_yy_ph_minority(size(TDF_yy_ph_minority,1):-1:relative_pos_minority_band_edge,:,:);
            TDF_yy_ph(pos_majority_band_edge:size(TDF_yy_ph,1),:,:) = TDF_yy_ph(pos_majority_band_edge:size(TDF_xx_ph,1),:,:) + TDF_yy_ph_majority((relative_pos_majority_band_edge:size(TDF_xx_ph_majority,1)),:,:);
            
            TDF_xy_ph(1:pos_minority_band_edge,:,:) = TDF_xy_ph_minority(size(TDF_xy_ph_minority,1):-1:relative_pos_minority_band_edge,:,:);
            TDF_xy_ph(pos_majority_band_edge:size(TDF_xy_ph,1),:,:) = TDF_xy_ph(pos_majority_band_edge:size(TDF_xx_ph,1),:,:) + TDF_xy_ph_majority((relative_pos_majority_band_edge:size(TDF_xy_ph_majority,1)),:,:);

            TDF_yx_ph(1:pos_minority_band_edge,:,:) = TDF_yx_ph_minority(size(TDF_yx_ph_minority,1):-1:relative_pos_minority_band_edge,:,:);
            TDF_yx_ph(pos_majority_band_edge:size(TDF_yx_ph,1),:,:) = TDF_yx_ph(pos_majority_band_edge:size(TDF_xx_ph,1),:,:) + TDF_yx_ph_majority((relative_pos_majority_band_edge:size(TDF_yx_ph_majority,1)),:,:);


            % composing the other energy dependent quantities
            NNan = isnan(MFP_x_ph_majority); MFP_x_ph_majority(NNan)=0;
            NNan = isnan(MFP_y_ph_minority); MFP_y_ph_minority(NNan)=0;
            NNan = isnan(MFP_y_ph_majority); MFP_y_ph_majority(NNan)=0;
            NNan = isnan(tauE_x_ph_minority); tauE_x_ph_minority(NNan)=0;
            NNan = isnan(tauE_x_ph_majority); tauE_x_ph_majority(NNan)=0;
            NNan = isnan(MFP_x_ph_minority); MFP_x_ph_minority(NNan)=0;
            NNan = isnan(tauE_y_ph_majority); tauE_y_ph_majority(NNan)=0;
            NNan = isnan(tauE_y_ph_minority); tauE_y_ph_minority(NNan)=0;
            if strcmp(negative_gap,'yes')
                MFP_x_ph(1:pos_minority_band_edge,:,:) = MFP_x_ph_minority(size(MFP_x_ph_minority,1):-1:relative_pos_minority_band_edge,:,:);
                MFP_x_ph(pos_majority_band_edge:size(MFP_x_ph,1),:,:) = merge_ave( MFP_x_ph(pos_majority_band_edge:size(MFP_x_ph,1),:,:) , MFP_x_ph_majority((relative_pos_majority_band_edge:size(MFP_x_ph_majority,1)),:,:) );

                MFP_y_ph(1:pos_minority_band_edge,:,:) = MFP_y_ph_minority(size(MFP_y_ph_minority,1):-1:relative_pos_minority_band_edge,:,:);
                MFP_y_ph(pos_majority_band_edge:size(MFP_y_ph,1),:,:) = merge_ave(MFP_y_ph(pos_majority_band_edge:size(MFP_y_ph,1),:,:) , MFP_y_ph_majority((relative_pos_majority_band_edge:size(MFP_x_ph_majority,1)),:,:) );

                tauE_x_ph(1:pos_minority_band_edge,:,:) = tauE_x_ph_minority(size(tauE_x_ph_minority,1):-1:relative_pos_minority_band_edge,:,:);
                tauE_x_ph(pos_majority_band_edge:size(tauE_x_ph,1),:,:) = merge_ave(tauE_x_ph(pos_majority_band_edge:size(tauE_x_ph,1),:,:) , tauE_x_ph_majority((relative_pos_majority_band_edge:size(tauE_x_ph_majority,1)),:,:) );

                tauE_y_ph(1:pos_minority_band_edge,:,:) = tauE_y_ph_minority(size(tauE_y_ph_minority,1):-1:relative_pos_minority_band_edge,:,:);
                tauE_y_ph(pos_majority_band_edge:size(tauE_y_ph,1),:,:) = merge_ave(tauE_y_ph(pos_majority_band_edge:size(tauE_y_ph,1),:,:) , tauE_y_ph_majority((relative_pos_majority_band_edge:size(tauE_x_ph_majority,1)),:,:) );
            else
                MFP_x_ph(1:pos_minority_band_edge,:,:) = MFP_x_ph_minority(size(MFP_x_ph_minority,1):-1:relative_pos_minority_band_edge,:,:);
                MFP_x_ph(pos_majority_band_edge:size(MFP_x_ph,1),:,:) = MFP_x_ph(pos_majority_band_edge:size(MFP_x_ph,1),:,:) + MFP_x_ph_majority((relative_pos_majority_band_edge:size(MFP_x_ph_majority,1)),:,:);

                MFP_y_ph(1:pos_minority_band_edge,:,:) = MFP_y_ph_minority(size(MFP_y_ph_minority,1):-1:relative_pos_minority_band_edge,:,:);
                MFP_y_ph(pos_majority_band_edge:size(MFP_y_ph,1),:,:) = MFP_y_ph(pos_majority_band_edge:size(MFP_y_ph,1),:,:) + MFP_y_ph_majority((relative_pos_majority_band_edge:size(MFP_x_ph_majority,1)),:,:);

                tauE_x_ph(1:pos_minority_band_edge,:,:) = tauE_x_ph_minority(size(tauE_x_ph_minority,1):-1:relative_pos_minority_band_edge,:,:);
                tauE_x_ph(pos_majority_band_edge:size(tauE_x_ph,1),:,:) = tauE_x_ph(pos_majority_band_edge:size(tauE_x_ph,1),:,:) + tauE_x_ph_majority((relative_pos_majority_band_edge:size(tauE_x_ph_majority,1)),:,:);

                tauE_y_ph(1:pos_minority_band_edge,:,:) = tauE_y_ph_minority(size(tauE_y_ph_minority,1):-1:relative_pos_minority_band_edge,:,:);
                tauE_y_ph(pos_majority_band_edge:size(tauE_y_ph,1),:,:) = tauE_y_ph(pos_majority_band_edge:size(tauE_y_ph,1),:,:) + tauE_y_ph_majority((relative_pos_majority_band_edge:size(tauE_x_ph_majority,1)),:,:);

            end
    
            
        else
            
            TDF_xx_ph=zeros(nE, nT ); TDF_yy_ph=zeros(nE, nT ); 
            TDF_xy_ph=zeros(nE, nT ); TDF_yx_ph=zeros(nE, nT );
            MFP_x_ph=zeros(nE, nT ); MFP_y_ph=zeros(nE, nT ); 
            tauE_x_ph=zeros(nE, nT ); tauE_y_ph=zeros(nE, nT ); 
            
            
            TDF_xx_ph(1:pos_minority_band_edge,:) = TDF_xx_ph_minority(size(TDF_xx_ph_minority,1):-1:relative_pos_minority_band_edge,:);
            TDF_xx_ph(pos_majority_band_edge:size(TDF_xx_ph,1),:) = TDF_xx_ph(pos_majority_band_edge:size(TDF_xx_ph,1),:) + TDF_xx_ph_majority((relative_pos_majority_band_edge:size(TDF_xx_ph_majority,1)),:);

            TDF_yy_ph(1:pos_minority_band_edge,:) = TDF_yy_ph_minority(size(TDF_yy_ph_minority,1):-1:relative_pos_minority_band_edge,:);
            TDF_yy_ph(pos_majority_band_edge:size(TDF_yy_ph,1),:) = TDF_yy_ph(pos_majority_band_edge:size(TDF_xx_ph,1),:) + TDF_yy_ph_majority((relative_pos_majority_band_edge:size(TDF_xx_ph_majority,1)),:);

            TDF_xy_ph(1:pos_minority_band_edge,:) = TDF_xy_ph_minority(size(TDF_xy_ph_minority,1):-1:relative_pos_minority_band_edge,:);
            TDF_xy_ph(pos_majority_band_edge:size(TDF_xy_ph,1),:) = TDF_xy_ph(pos_majority_band_edge:size(TDF_xx_ph,1),:) + TDF_xy_ph_majority((relative_pos_majority_band_edge:size(TDF_xy_ph_majority,1)),:);
            
            TDF_yx_ph(1:pos_minority_band_edge,:) = TDF_yx_ph_minority(size(TDF_yx_ph_minority,1):-1:relative_pos_minority_band_edge,:);
            TDF_yx_ph(pos_majority_band_edge:size(TDF_yx_ph,1),:) = TDF_yx_ph(pos_majority_band_edge:size(TDF_xx_ph,1),:) + TDF_yx_ph_majority((relative_pos_majority_band_edge:size(TDF_yx_ph_majority,1)),:);


            % composing the other energy dependent quantities
            NNan = isnan(MFP_x_ph_majority); MFP_x_ph_majority(NNan)=0;
            NNan = isnan(MFP_y_ph_minority); MFP_y_ph_minority(NNan)=0;
            NNan = isnan(MFP_y_ph_majority); MFP_y_ph_majority(NNan)=0;
            NNan = isnan(tauE_x_ph_minority); tauE_x_ph_minority(NNan)=0;
            NNan = isnan(tauE_x_ph_majority); tauE_x_ph_majority(NNan)=0;
            NNan = isnan(MFP_x_ph_minority); MFP_x_ph_minority(NNan)=0;
            NNan = isnan(tauE_y_ph_majority); tauE_y_ph_majority(NNan)=0;
            NNan = isnan(tauE_y_ph_minority); tauE_y_ph_minority(NNan)=0;
            if strcmp(negative_gap,'yes')
                MFP_x_ph(1:pos_minority_band_edge,:) = MFP_x_ph_minority(size(MFP_x_ph_minority,1):-1:relative_pos_minority_band_edge,:);
                MFP_x_ph(pos_majority_band_edge:size(MFP_x_ph,1),:) = merge_ave( MFP_x_ph(pos_majority_band_edge:size(MFP_x_ph,1),:) , MFP_x_ph_majority((relative_pos_majority_band_edge:size(MFP_x_ph_majority,1)),:) );

                MFP_y_ph(1:pos_minority_band_edge,:) = MFP_y_ph_minority(size(MFP_y_ph_minority,1):-1:relative_pos_minority_band_edge,:);
                MFP_y_ph(pos_majority_band_edge:size(MFP_y_ph,1),:) = merge_ave(MFP_y_ph(pos_majority_band_edge:size(MFP_y_ph,1),:) , MFP_y_ph_majority((relative_pos_majority_band_edge:size(MFP_x_ph_majority,1)),:) );

                tauE_x_ph(1:pos_minority_band_edge,:) = tauE_x_ph_minority(size(tauE_x_ph_minority,1):-1:relative_pos_minority_band_edge,:);
                tauE_x_ph(pos_majority_band_edge:size(tauE_x_ph,1),:) = merge_ave(tauE_x_ph(pos_majority_band_edge:size(tauE_x_ph,1),:) , tauE_x_ph_majority((relative_pos_majority_band_edge:size(tauE_x_ph_majority,1)),:) );

                tauE_y_ph(1:pos_minority_band_edge,:) = tauE_y_ph_minority(size(tauE_y_ph_minority,1):-1:relative_pos_minority_band_edge,:);
                tauE_y_ph(pos_majority_band_edge:size(tauE_y_ph,1),:) = merge_ave(tauE_y_ph(pos_majority_band_edge:size(tauE_y_ph,1),:) , tauE_y_ph_majority((relative_pos_majority_band_edge:size(tauE_x_ph_majority,1)),:) );
            else
                MFP_x_ph(1:pos_minority_band_edge,:) = MFP_x_ph_minority(size(MFP_x_ph_minority,1):-1:relative_pos_minority_band_edge,:);
                MFP_x_ph(pos_majority_band_edge:size(MFP_x_ph,1),:) = MFP_x_ph_majority((relative_pos_majority_band_edge:size(MFP_x_ph_majority,1)),:);

                MFP_y_ph(1:pos_minority_band_edge,:) = MFP_y_ph_minority(size(MFP_y_ph_minority,1):-1:relative_pos_minority_band_edge,:);
                MFP_y_ph(pos_majority_band_edge:size(MFP_y_ph,1),:) = MFP_y_ph_majority((relative_pos_majority_band_edge:size(MFP_x_ph_majority,1)),:);

                tauE_x_ph(1:pos_minority_band_edge,:) = tauE_x_ph_minority(size(tauE_x_ph_minority,1):-1:relative_pos_minority_band_edge,:);
                tauE_x_ph(pos_majority_band_edge:size(tauE_x_ph,1),:) = tauE_x_ph_majority((relative_pos_majority_band_edge:size(tauE_x_ph_majority,1)),:);

                tauE_y_ph(1:pos_minority_band_edge,:) = tauE_y_ph_minority(size(tauE_y_ph_minority,1):-1:relative_pos_minority_band_edge,:);
                tauE_y_ph(pos_majority_band_edge:size(tauE_y_ph,1),:) = tauE_y_ph_majority((relative_pos_majority_band_edge:size(tauE_x_ph_majority,1)),:);
            end
            
        end
        
        
        
        TDF_ph.xx = TDF_xx_ph; TDF_ph.xy = TDF_xy_ph; 
        TDF_ph.yx = TDF_yx_ph; TDF_ph.yy = TDF_yy_ph; 

        MFP_ph.x = MFP_x_ph; MFP_ph.y = MFP_y_ph; 
        tauE_ph.x = tauE_x_ph; tauE_ph.y = tauE_y_ph;   
        
        
    end
    
        
end

function C = merge_ave(A,B)

    C = zeros(size(A,1),size(A,2),size(A,3));
    nv2 = size(A,2) ;
    nv3 = size(A,3) ;
    for i_v2 = 1:nv2
        for i_v3 = 1:nv3            
            A_t = A(:,i_v2,i_v3);
            B_t = B(:,i_v2,i_v3);
            [na,ma] =  find( A_t );
            [nb,mb] =  find( B_t );
            C(:,i_v2,i_v3) = A_t+B_t;
            C(intersect(ma,mb),i_v2,i_v3) = ( A_t((intersect(ma,mb)))+B_t((intersect(ma,mb))) )/2 ;
        end
    end
        
end