% Copyright 2022 Patrizio Graziosi                                        %
% A creation of Patrizio Graziosi, written and developed by               %
% Patrizio Graziosi, patrizio.graziosi@cnr.it, during the                 %  
% Marie Curie - Individual Fellowships  GENESIS - project ID 788465       %
% Generic transport simulator for new generation thermoelectric materials %
%                                                                         %
% ----------------------------------------------------------------------- %
% This file is distributed under the terms of the GNU                     %
% General Public License.                                                 %
% ----------------------------------------------------------------------- %
%                                                                         %
% Please cite:                                                            %
% Journal of Applied Physics 126, 155701 (2019); 
% https://doi.org/10.1063/1.5116793
% when publishing results obtained  using the present  code               %
% ----------------------------------------------------------------------- %

% this code writes the TDFs in terms of a constant mean free path lambda
% starting from the state_ID 

% NOTE
% the state_ID shall be open in the workspace
% and the others relevant quantities like E_array and T_array as well.


% set lambda


function [TDF_electron_CMFP, TDF_n_electron_CMFP, tauE_electron_CMFP, tauE_n_electron_CMFP] = TDF_CMFP_ELECTRA(WorkSpace4)

lambda = 5e-9; % in m



    state_ID = WorkSpace4.state_ID ;           % state ID struct and quantities
    E_array = WorkSpace4.E_array ;
    
    n_bands_transp = WorkSpace4.n_bands_transp ;
    
     sd = WorkSpace4.sd ;
     
     nE = size(E_array,2) ;
     
%      q0=1.609e-19;             % [col]
%     kB=1.38e-23;              % [J/K]
    
    
    
    TDF_n=struct(); tauE_n=struct(); TDF=struct(); tauE=struct(); 
    
    
    % fields with the different bands
    TDF_n.xx = zeros(nE,n_bands_transp); TDF_n.yy = zeros(nE,n_bands_transp); TDF_n.zz = zeros(nE,n_bands_transp);
    tauE_n.x = zeros(nE,n_bands_transp); tauE_n.y = zeros(nE,n_bands_transp); tauE_n.z = zeros(nE,n_bands_transp);
    


%calculation of the Transport Density Fnction, 1D array with the TDF values,
%the size is the same of the E_array
        for id_E=1:size(E_array,2) %parfor
            for id_n=1:n_bands_transp 
                                
                            if not(size(state_ID(id_E,id_n).DOS)) == 0   % the state is involved in the transport

                                        TDF_n.xx(id_E,id_n) = sum(abs(state_ID(id_E,id_n).v_x) .* lambda ...
                                            .* state_ID(id_E,id_n).DOS); 

                                        TDF_n.yy(id_E,id_n) = sum(abs(state_ID(id_E,id_n).v_y) .* lambda ...
                                            .* state_ID(id_E,id_n).DOS); 

                                        TDF_n.zz(id_E,id_n) = sum(abs(state_ID(id_E,id_n).v_z) .* lambda ...
                                            .* state_ID(id_E,id_n).DOS);                                    
                                        
                                        tauE_n.x(id_E,id_n) = sum( lambda ./ abs(state_ID(id_E,id_n).v_x) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                                        tauE_n.y(id_E,id_n) = sum( lambda ./ abs(state_ID(id_E,id_n).v_y) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                                        tauE_n.z(id_E,id_n) = sum( lambda ./ abs(state_ID(id_E,id_n).v_z) .* state_ID(id_E,id_n).DOS ) ./ sum(state_ID(id_E,id_n).DOS);
                                        
                            end
            end           
        end
        TDF.xx = (sd/((2*pi)^3)).*squeeze(sum(TDF_n.xx,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
        TDF.yy = (sd/((2*pi)^3)).*squeeze(sum(TDF_n.yy,2));
        TDF.zz = (sd/((2*pi)^3)).*squeeze(sum(TDF_n.zz,2));
              
        tauE.x = squeeze(sum(tauE_n.x,2)); % this sums the contributions along the second dimensions, the bands, giving a matrix of Energy values by Fermi level positions and T
        tauE.y = squeeze(sum(tauE_n.x,2)); % tauE = tauE(E,EF,T)
        tauE.z = squeeze(sum(tauE_n.x,2));
       
        
        
        TDF_electron_CMFP = TDF ; 
        TDF_n_electron_CMFP = TDF_n ;
        tauE_electron_CMFP = tauE ; 
        tauE_n_electron_CMFP = tauE ;        
        
end