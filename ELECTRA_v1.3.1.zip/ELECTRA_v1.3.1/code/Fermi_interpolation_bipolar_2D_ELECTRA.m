% Copyright 2022 Patrizio Graziosi                                        %
% A creation of Patrizio Graziosi, written and developed by               %
% Patrizio Graziosi, patrizio.graziosi@cnr.it, during the                 %  
% Marie Curie - Individual Fellowships  GENESIS - project ID 788465       %
% Generic transport simulator for new generation thermoelectric materials %
%                                                                         %
% ----------------------------------------------------------------------- %
% This file is distributed under the terms of the GNU                     %
% General Public License.                                                 %
% ----------------------------------------------------------------------- %
%                                                                         %
% Please cite the code source and the author when publishing results      %
% obtained  using the present  code                                       %
% ACS Appl. Energy Mater. 2020, 3, 6, 5913–5926
% https://doi.org/10.1021/acsaem.0c00825
%                                                                         %
% ----------------------------------------------------------------------- %


% calculation ot the Fermi array at each temperature
% considering the charge that comes from both the CB and the VB


function [EF_M_ph_temp , N_M_ph_temp] = Fermi_interpolation_bipolar_2D_ELECTRA(EF_matrix, EF_array_ph, T_array, Ek, kx_matrix, ky_matrix, sd, pseudoconduction_bands, pseudovalence_bands ) %#codegen
            % same as above but considering both CBs and VBs %#codegen

Ek(isnan(Ek)) = Inf;

% ----------------------- k space surface element -------------------------
dkx_s = [kx_matrix(2,1) ky_matrix(2,1) 0] - [kx_matrix(1,1) ky_matrix(1,1) 0];
dky_s = [kx_matrix(1,2) ky_matrix(1,2) 0] - [kx_matrix(1,1) ky_matrix(1,1) 0];
dSk = abs( norm(cross(dkx_s,dky_s))  );
% ------------------------------------------------------------------------

mp = zeros(1,size(EF_matrix,1));
for i = size(EF_matrix,1):-1:1
    [~,m] = min(abs(EF_array_ph -EF_matrix(i,1)));
    mp(i) = m;
end

EF_M_ph_temp = zeros(size(EF_array_ph,2),size(T_array,2));
for i = 1:size(EF_M_ph_temp,2)
    EF_M_ph_temp(mp,i) = EF_matrix(:,i);
end

[np,~] = find((EF_M_ph_temp(:,1))~=0) ;
x_fictitious = 1:201;
nq = ones(1,201);
nq(np) = 0;

for i = 1:size(EF_M_ph_temp,2)
    a = interp1(np, EF_M_ph_temp(np,i)' , x_fictitious(logical(nq)) , 'makima' );
    EF_M_ph_temp(x_fictitious(logical(nq)),i) = a';
end


if exist('sd','var')
else
    sd = 2;
end   
%------------ % Physical Constants -----------------
q0=1.609e-19;             % [col]
kB=1.38e-23;              % [J/K]
%----------------------------------------------------

N_M_ph_temp = zeros(size(EF_array_ph,2),size(T_array,2));

for id_EF = size(EF_array_ph,2) : -1 : 1       
     for id_T = 1:size(T_array,2)

         EF_temp = EF_M_ph_temp(id_EF,id_T);

         N_M_ph_temp(id_EF,id_T) = ...
                sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((Ek(:,:,pseudoconduction_bands)-EF_temp)./(kB*T_array(id_T)/q0))+1)))) - ...
                sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((-Ek(:,:,pseudovalence_bands)+EF_temp)./(kB*T_array(id_T)/q0))+1))));
         
     end    
end



end