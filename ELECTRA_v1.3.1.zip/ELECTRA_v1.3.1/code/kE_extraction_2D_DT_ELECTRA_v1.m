% Copyright 2021 Patrizio Graziosi                                        %
% A creation of Patrizio Graziosi, written and developed by               %
% Patrizio Graziosi, patrizio.graziosi@cnr.it, during the                 %  
% Marie Curie - Individual Fellowships  GENESIS - project ID 788465       %
% Generic transport simulator for new generation thermoelectric materials %
%                                                                         %
% ----------------------------------------------------------------------- %
% This file is distributed under the terms of the GNU                     %
% General Public License.                                                 %
% ----------------------------------------------------------------------- %
%                                                                         %
% Please cite:                                                            %
% Journal of Applied Physics 126, 155701 (2019); 
% https://doi.org/10.1063/1.5116793
% when publishing results obtained  using the present  code               %
% ----------------------------------------------------------------------- %




function [state_ID_temp,DOS,V] = kE_extraction_2D_DT_ELECTRA_v1(id_E,n_band,E_array,bands_transp,Ek,kx_matrix,ky_matrix,sd,BZ_factor)  %#codegen

%------------------- Initializations ---------------------------------
nkx=size(Ek,1); nky=size(Ek,2);
Etmp = E_array(id_E);
n = bands_transp(n_band); %the band index, that does not correponsd to the position in the bands_transp array, but in the E(k) matrix
hbar=(6.6261e-34)/(2*pi); % [J-sec]
q0=1.609e-19;             % [col]
%--------------------------------------------------------------------


% ---------------------- Declaration --------------------------------
kx_field =  [] ; % double.empty(1,0);
coder.varsize('kx_field');
ky_field =  [] ; % double.empty(1,0);
coder.varsize('ky_field');
knorm_field =  [] ; %  double.empty(1,0);
coder.varsize('knorm_field');

vx_field =  [] ; % double.empty(1,0);
coder.varsize('vx_field');
vy_field =  [] ; %  double.empty(1,0);
coder.varsize('vy_field');
V_field =   [] ; % double.empty(1,0);
coder.varsize('V_field');

DOS_field =  [] ; % double.empty(1,0);
coder.varsize('DOS_field');

dkL_field =  [] ; % double.empty(1,0);
coder.varsize('dkL_field');

% -------------------------------------------------------------------


% construction of the matrix that contains the relative numeric indexes of
% % vertexes of the the six tetrahedra to divide each 3D mesh element
% P = [ 1     1
%       1     2
%       2     1
%       2     2 ] ;
% % % connettivity matrix between vertexes DT matrix
% DT_matrix = [   4     2     3
%                 2     1     3   ] ;





        Emin_temp=min(min(min((Ek(:,:,n)))));
        Emax_temp=max(max(max((Ek(:,:,n)))));
        
        if Emin_temp<Etmp && Emax_temp>Etmp % select only the band if crossing that E value
            
            for ix = 1 : (nkx-1) % nkx is the number of k points in the x axis, y and z m.m.
                for iy = 1 : (nky-1)
                        
                        kx_cond1 = ( Ek(ix,iy,n) <= Etmp && Ek(ix+1,iy,n) > Etmp || Ek(ix,iy,n) >= Etmp && Ek(ix+1,iy,n) < Etmp );
                        kx_cond2 = ( Ek(ix,iy+1,n) <= Etmp && Ek(ix+1,iy+1,n) > Etmp || Ek(ix,iy+1,n) >= Etmp && Ek(ix+1,iy+1,n) < Etmp );
                        
                        ky_cond1 = ( Ek(ix,iy,n) <= Etmp && Ek(ix,iy+1,n) > Etmp || Ek(ix,iy,n) >= Etmp && Ek(ix,iy+1,n) < Etmp );
                        ky_cond2 = ( Ek(ix+1,iy,n) <= Etmp && Ek(ix+1,iy+1,n) > Etmp || Ek(ix+1,iy,n) >= Etmp && Ek(ix+1,iy+1,n) < Etmp );
                                                
                        % is the 2D mesh element crossed by the surface?
                        if kx_cond1 || ky_cond1 || kx_cond2 || ky_cond2
                            
                            for iT = 1:2 % this identfy the triangle iT
%                                 Tri = DT_matrix(iT,:); % this gives the three points that are the triangle vertexes inside the DT
                                
                                Axn = ix + iT - 1;  % identification of the vertex coordinates, Vin is the point index, Vi is its i-coordinate in k-space
                                Ayn = iy + iT - 1; 
                                Ax = kx_matrix(Axn,Ayn);
                                Ay = ky_matrix(Axn,Ayn);
                                E_A = Ek(Axn,Ayn,n); % Energy value corresponding at the Vertex

                                Bxn = ix + 1; 
                                Byn = iy ; 
                                Bx = kx_matrix(Bxn,Byn);
                                By = ky_matrix(Bxn,Byn);
                                E_B = Ek(Bxn,Byn,n);

                                Cxn = ix ; 
                                Cyn = iy + 1;
                                Cx = kx_matrix(Cxn,Cyn);
                                Cy = ky_matrix(Cxn,Cyn);
                                E_C = Ek(Cxn,Cyn,n);
                
%                                 Evtmp=[Ek(i,j,l,n);Ek(i+1,j,l,n);Ek(i,j+1,l,n);Ek(i,j,l+1,n)]; % 1st pyramid P1, ABCD
                                Evtmp = [E_A;E_B;E_C]; % iP pyramid , generically ABCD
                                EminP = min(Evtmp); 
                                EmaxP = max(Evtmp);
                                
                                
                                % is the tethraedron crossed by the surface?
                                if EminP<Etmp && EmaxP>Etmp % then the code considers the generic ABCD Pyramid (numbered iP)

                                    [kx, ky, knorm, Vx, Vy, V, DOS, dkL] = Triangle_explore_Lehmann_variation(Ax, Ay, Bx, By, Cx, Cy, E_A, E_B, E_C, Etmp) ;
                                    
                                    
                                    kx_field = [kx_field, kx];
                                    ky_field = [ky_field, ky];
                                    knorm_field = [knorm_field, knorm];
                                    
                                    vx_field = [vx_field, Vx];
                                    vy_field = [vy_field, Vy];
                                    V_field = [ V_field, V];
                                    
                                    DOS_field = [ DOS_field, DOS];
                                    
                                    dkL_field = [ dkL_field, dkL];

                                end

                            end
                        end
                        
                end
            end
        end
                   
        
        % integrals calculations for each band and each energy, the
        % 2/(8*pi^3) factor is introduced here
        NNan=isnan(DOS_field); DOS_field(NNan)=0;
        NInf=isinf(DOS_field); DOS_field(NInf)=0;
        NNan=isnan(vx_field);  vx_field(NNan)=0;
        NNan=isnan(vy_field);  vy_field(NNan)=0;
        NNan=isnan(V_field);   V_field(NNan)=0;
        
        k_points_number = size(kx_field,2);
         
        
        
        state_ID_temp = struct();
        
        state_ID_temp.kx = kx_field ;
        state_ID_temp.ky = ky_field ;
        state_ID_temp.knorm = knorm_field ;
        
        state_ID_temp.v_x = vx_field ;
        state_ID_temp.v_y = vy_field ;
        state_ID_temp.V = V_field;         
        
        state_ID_temp.DOS = DOS_field ;
        state_ID_temp.line = dkL_field ;
        state_ID_temp.E = Etmp;
        
        
        V = sum(state_ID_temp.V) / k_points_number ; % <v> ?  line 842 obiavtes to NaN issues
        
        DOS = BZ_factor*(sd/(4*pi^2))*sum( state_ID_temp.DOS); % Surface integration, the dAk element is in the DOS of the individual states





% subfunction pyramid_explore Lehamnn's and Taut's On the Numerical
% Calculation of the Density of Sates abd Related Properties, phys. stat.
% sol. (b) 54, 469 (1972)

    function [kx, ky, knorm, Vx, Vy, V, DOS, dkL] = Triangle_explore_Lehmann_variation(Ax, Ay, Bx, By, Cx, Cy, E_A, E_B, E_C, Etmp)   %#codegen

        Av_cond = ( E_A < Etmp && E_B > Etmp && E_C > Etmp ) || ( E_A > Etmp && E_B < Etmp && E_C < Etmp );
        Bv_cond = ( E_B < Etmp && E_A > Etmp && E_C > Etmp ) || ( E_B > Etmp && E_A < Etmp && E_C < Etmp );
        Cv_cond = ( E_C < Etmp && E_A > Etmp && E_B > Etmp ) || ( E_C > Etmp && E_A < Etmp && E_B < Etmp );
%         ABv_cond = ( E_A < Etmp && E_B < Etmp && E_C > Etmp ) || ( E_A > Etmp && E_B > Etmp && E_C < Etmp );
%         ACv_cond = ( E_A < Etmp && E_C < Etmp && E_B > Etmp ) || ( E_A > Etmp && E_C > Etmp && E_B < Etmp );

        kx = [] ; %  single.empty(1,0); 
        coder.varsize('kx');
        ky = [] ; %  single.empty(1,0); 
        coder.varsize('ky');
        knorm = [] ; % single.empty(1,0);
        coder.varsize('knorm');
        Vx = [] ; %  single.empty(1,0);
        coder.varsize('Vx');
        Vy = [] ; %  single.empty(1,0); 
        coder.varsize('Vy');
        V = [] ; %  single.empty(1,0);
        coder.varsize('V');
        DOS = [] ; %  single.empty(1,0);
        coder.varsize('DOS');
        dkL = [] ; %  single.empty(1,0);
        coder.varsize('dkL');

        if Av_cond % A vertex

            k1x = Ax + (Bx-Ax) * abs((Etmp-E_A) / (E_B-E_A));  %A-B
            k1y = Ay + (By-Ay) * abs((Etmp-E_A) / (E_B-E_A));
            k2x = Ax + (Cx-Ax) * abs((Etmp-E_A) / (E_C-E_A)); %A-C
            k2y = Ay + (Cy-Ay) * abs((Etmp-E_A) / (E_C-E_A));

            %  put the point in the state_ID of the state                            
            kx = [kx, (k1x+k2x)/2 ] ;
            ky = [ky, (k1y+k2y)/2 ] ;
            knorm = [knorm, norm([(k1x+k2x)/2,(k1y+k2y)/2]) ];

            % composition of the DOS(E)
            % DOS(E) is the average of the bandstructure DOS at the k points above defined, a sort of linear interpolation of the DOS versus k along the pyramid edges 
            k12 = norm([k2x-k1x,k2y-k1y]);
            sp = k12;
            dkL = sp; % surface element for the integration, Heron's formula

            % Define the DOS at the intermediate points 
            % variation from Lehmann 1972

            k1 = [Bx, By , 0] - [Ax, Ay , 0];
            k2 = [Cx, Cy , 0] - [Ax, Ay , 0];
            sT = norm(cross(k1,k2)); % surface of the triasngular element times 2(?)
            r1 = k1/sT;
            r2 = k2/sT;
            grad_E = (E_B - E_A)*r1 + (E_C-E_A)*r2 ;

            % Define DOS and velocities in correct units
        %     DOS_temp=dkS*(DOS_1+DOS_2+DOS_3)/3;
            Vx_k = q0/hbar * grad_E(1);
            Vy_k = q0/hbar * grad_E(2);
            V_temp = q0/hbar * norm( grad_E );
            DOS_temp = dkL / norm( grad_E ) ;

            Vx = [Vx, Vx_k ] ;
            Vy = [Vy, Vy_k ] ;
            V = [V, V_temp ];
            DOS = [DOS, DOS_temp ]; 


        elseif Bv_cond % B vertex

            k1x = Bx + (Ax-Bx) * abs((Etmp-E_B) / (E_A-E_B)); %B-A
            k1y = By + (Ay-By) * abs((Etmp-E_B) / (E_A-E_B));
            k2x = Bx + (Cx-Bx) * abs((Etmp-E_B) / (E_C-E_B)); % B-C
            k2y = By + (Cy-By) * abs((Etmp-E_B) / (E_C-E_B));

            %  put the point in the state_ID of the state                            
            kx = [kx, (k1x+k2x)/2 ] ;
            ky = [ky, (k1y+k2y)/2 ] ;
            knorm = [knorm, norm([(k1x+k2x)/2,(k1y+k2y)/2]) ];

            k12 = norm([k2x-k1x,k2y-k1y]);
            sp = (k12);
            dkL = sp ;

        % Define the DOS at the intermediate points 
            % variation from Lehmann 1972

            k1 = [Bx, By , 0] - [Ax, Ay , 0]; % always the same to acoid crossing diagonals
            k2 = [Cx, Cy , 0] - [Ax, Ay , 0];
            sT = norm(cross(k1,k2)); % surface of the triasngular element times 2(?)
            r1 = k1/sT;
            r2 = k2/sT;
            grad_E = (E_B - E_A)*r1 + (E_C-E_A)*r2 ;

            % Define DOS and velocities in correct units
        %     DOS_temp=dkS*(DOS_1+DOS_2+DOS_3)/3;
            Vx_k = q0/hbar * grad_E(1);
            Vy_k = q0/hbar * grad_E(2);
            V_temp = q0/hbar * norm( grad_E );
            DOS_temp = dkL / norm( grad_E ) ;

            Vx = [Vx, Vx_k ] ;
            Vy = [Vy, Vy_k ] ;
            V = [V, V_temp ];
            DOS = [DOS, DOS_temp ];



        elseif Cv_cond % C vertex

            k1x = Cx + (Ax-Cx) * abs((Etmp-E_C) / (E_A-E_C)); %C-A
            k1y = Cy + (Ay-Cy) * abs((Etmp-E_C) / (E_A-E_C));
            k2x = Cx + (Bx-Cx) * abs((Etmp-E_C) / (E_B-E_C)); % C-B
            k2y = Cy + (By-Cy) * abs((Etmp-E_C) / (E_B-E_C));

            %  put the point in the state_ID of the state                            
            kx = [kx, (k1x+k2x)/2] ;
            ky = [ky, (k1y+k2y)/2 ] ;
            knorm = [knorm, norm([(k1x+k2x)/2,(k1y+k2y)/2]) ];

            k12 = norm([k2x-k1x,k2y-k1y]);
            sp = (k12);
            dkL = sp;


          % Define the DOS at the intermediate points 
            % variation from Lehmann 1972    
            k1 = [Bx, By , 0] - [Ax, Ay , 0];
            k2 = [Cx, Cy , 0] - [Ax, Ay , 0];
            sT = norm(cross(k1,k2)); % surface of the triasngular element times 2(?)
            r1 = k1/sT;
            r2 = k2/sT;
            grad_E = (E_B - E_A)*r1 + (E_C-E_A)*r2 ;

            % Define DOS and velocities in correct units
        %     DOS_temp=dkS*(DOS_1+DOS_2+DOS_3)/3;
            Vx_k = q0/hbar * grad_E(1);
            Vy_k = q0/hbar * grad_E(2);
            V_temp = q0/hbar * norm( grad_E );
            DOS_temp = dkL / norm( grad_E ) ;

            Vx = [Vx, Vx_k ] ;
            Vy = [Vy, Vy_k ] ;
            V = [V, V_temp ];
            DOS = [DOS, DOS_temp ];
       
        end 

        
    end


end
