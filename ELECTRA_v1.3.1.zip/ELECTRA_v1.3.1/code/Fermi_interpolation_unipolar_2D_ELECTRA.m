% Copyright 2022 Patrizio Graziosi                                        %
% A creation of Patrizio Graziosi, written and developed by               %
% Patrizio Graziosi, patrizio.graziosi@cnr.it during the                  %  
% Marie Curie - Individual Fellowships  GENESIS - project ID 788465       %
% Generic transport simulator for new generation thermoelectric materials %
%                                                                         %
% ----------------------------------------------------------------------- %
% This file is distributed under the terms of the GNU                     %
% General Public License.                                                 %
% ----------------------------------------------------------------------- %
%                                                                         %
% Please cite:                                                            %
% Journal of Applied Physics 126, 155701 (2019); 
% https://doi.org/10.1063/1.5116793
% when publishing results obtained  using the present  code               %
% ----------------------------------------------------------------------- %

% calculation ot the Fermi array at each temperature
% considering the carriers' density to be constant, i.e. in the extrinsic
% region
% it exploits a sum over k points
% it needs of the Ek and of a bands_transp array that contains the only
% bands that are involved in the transport

function [EF_M_ph_temp , N_M_ph_temp] = Fermi_interpolation_unipolar_2D_ELECTRA( EF_matrix, EF_array_ph, T_array, Ek, kx_matrix, ky_matrix, sd, bands_transp) %#codegen

Ek(isnan(Ek)) = Inf;

% ----------------------- k space surface element -------------------------
dkx_s = [kx_matrix(2,1) ky_matrix(2,1) 0] - [kx_matrix(1,1) ky_matrix(1,1) 0];
dky_s = [kx_matrix(1,2) ky_matrix(1,2) 0] - [kx_matrix(1,1) ky_matrix(1,1) 0];
dSk = abs( norm(cross(dkx_s,dky_s))  );
% ------------------------------------------------------------------------


mp = zeros(1,size(EF_matrix,1));
for i = size(EF_matrix,1):-1:1
    [~,m] = min(abs(EF_array_ph -EF_matrix(i,1)));
    mp(i) = m;
end

EF_M_ph_temp = zeros(size(EF_array_ph,2),size(T_array,2));
for i = 1:size(EF_M_ph_temp,2)
    EF_M_ph_temp(mp,i) = EF_matrix(:,i);
end

[np,~] = find((EF_M_ph_temp(:,1))~=0) ;
x_fictitious = 1:201;
nq = ones(1,201);
nq(np) = 0;

for i = 1:size(EF_M_ph_temp,2)
    a = interp1(np, EF_M_ph_temp(np,i)' , x_fictitious(logical(nq)) , 'makima' );
    EF_M_ph_temp(x_fictitious(logical(nq)),i) = a';
end


%------------ % Physical Constants -----------------
q0=1.609e-19;             % [col]
kB=1.38e-23;              % [J/K]
%----------------------------------------------------

N_M_ph_temp = zeros(size(EF_array_ph,2),size(T_array,2));

for id_EF = size(EF_array_ph,2) : -1 : 1 
     for id_T = 1:size(T_array,2)

         EF_temp = EF_M_ph_temp(id_EF,id_T);
         
         N_M_ph_temp(id_EF,id_T) = sd/(2*pi)^2*dSk*sum(sum(sum(1./(exp((Ek(:,:,bands_transp(1):bands_transp(size(bands_transp,2)))-EF_temp)./(kB*T_array(id_T)/q0))+1)))); % in m^-3

     end    
end


end