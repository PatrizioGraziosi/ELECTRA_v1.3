% Copyright 2022 Patrizio Graziosi                                        %
% A creation of Patrizio Graziosi, written and developed by               %
% Patrizio Graziosi, patrizio.graziosi@cnr.it during the                  %  
% Marie Curie - Individual Fellowships  GENESIS - project ID 788465       %
% Generic transport simulator for new generation thermoelectric materials %
%                                                                         %
% ----------------------------------------------------------------------- %
% This file is distributed under the terms of the GNU                     %
% General Public License.                                                 %
% ----------------------------------------------------------------------- %
%                                                                         %
% Please cite:                                                            %
% Journal of Applied Physics 126, 155701 (2019); 
% https://doi.org/10.1063/1.5116793
% when publishing results obtained  using the present  code               %
% ----------------------------------------------------------------------- %

% calculation ot the Fermi array at each temperature
% considering the carriers' density to be constant, i.e. in the extrinsic
% region
% it exploits a sum over k points
% it needs of the Ek and of a bands_transp array that contains the only
% bands that are involved in the transport

function [EF_matrix, N_imp_matrix] = Fermi_shift_unipolar_ELECTRA( EF_array, T_array, Ek, kx_matrix, ky_matrix, kz_matrix, sd, bands_transp ) %#codegen

Ek(isnan(Ek)) = Inf;

dkx_v = [kx_matrix(2,1,1) ky_matrix(2,1,1) kz_matrix(2,1,1)] - [kx_matrix(1,1,1) ky_matrix(1,1,1) kz_matrix(1,1,1)];
dky_v = [kx_matrix(1,2,1) ky_matrix(1,2,1) kz_matrix(1,2,1)] - [kx_matrix(1,1,1) ky_matrix(1,1,1) kz_matrix(1,1,1)];
dkz_v = [kx_matrix(1,1,2) ky_matrix(1,1,2) kz_matrix(1,1,2)] - [kx_matrix(1,1,1) ky_matrix(1,1,1) kz_matrix(1,1,1)];
dVk = abs( dot(cross(dkx_v,dky_v),dkz_v) );


EF_matrix = zeros(size(EF_array,2),size(T_array,2)); N_imp_matrix=EF_matrix;

[~, nT]=min(T_array-300);
EF_matrix(:,nT) = EF_array;

%------------ % Physical Constants -----------------
q0=1.609e-19;             % [col]
kB=1.38e-23;              % [J/K]
%----------------------------------------------------

for id_EF = size(EF_array,2) : -1 : 1
    
        N_imp_temp = sd/(2*pi)^3*dVk*sum(sum(sum(sum(1./(exp((Ek(:,:,:,bands_transp(1):bands_transp(size(bands_transp,2)))-EF_array(id_EF))./(kB*T_array(nT)/q0))+1))))); % impurities densities at 300 K, it is thought to be constant at each temperature
      
     for id_T = 1:size(T_array,2)
         if id_T ~= nT

             EF_temp = EF_array(id_EF);

             N_imp_new = sd/(2*pi)^3*dVk*sum(sum(sum(sum(1./(exp((Ek(:,:,:,bands_transp(1):bands_transp(size(bands_transp,2)))-EF_temp)./(kB*T_array(id_T)/q0))+1))))); % in m^-3


             EF1 = EF_temp;
             EF2 = EF_temp + kB*T_array(id_T)/q0; 
             EF0 = EF_temp - kB*T_array(id_T)/q0;
             n0 = sd/(2*pi)^3*dVk*sum(sum(sum(sum(1./(exp((Ek(:,:,:,bands_transp(1):bands_transp(size(bands_transp,2)))-EF0)./(kB*T_array(id_T)/q0))+1))))) - N_imp_temp; % in m^-3
             n1 = N_imp_new - N_imp_temp;
             n2 = sd/(2*pi)^3*dVk*sum(sum(sum(sum(1./(exp((Ek(:,:,:,bands_transp(1):bands_transp(size(bands_transp,2)))-EF2)./(kB*T_array(id_T)/q0))+1))))) - N_imp_temp; % in m^-3


             iF = 1;
             while n1*n2 > 0 && n0*n1 > 0
                iF = iF+1;
                EF2 = EF_temp + iF * kB*T_array(id_T)/q0; 
                EF0 = EF_temp - iF * kB*T_array(id_T)/q0;

                n0 = sd/(2*pi)^3*dVk*sum(sum(sum(sum(1./(exp((Ek(:,:,:,bands_transp(1):bands_transp(size(bands_transp,2)))-EF0)./(kB*T_array(id_T)/q0))+1))))) - N_imp_temp; % in m^-3
                n2 = sd/(2*pi)^3*dVk*sum(sum(sum(sum(1./(exp((Ek(:,:,:,bands_transp(1):bands_transp(size(bands_transp,2)))-EF2)./(kB*T_array(id_T)/q0))+1))))) - N_imp_temp; % in m^-3            
             end

             Delta_N = abs(n1) / N_imp_temp;
             if isnan(Delta_N)
                 Delta_N = 0;
             end


            while abs(Delta_N) > 0.004

                if n2*n1 < 0
                    EFa = EF2;
                    EFb = EF1;
                    EFc = (EF2 + EF1)/2;
                    v_EF = [EFa, EFb, EFc];
                    EF2 = max( v_EF );
                    EF0 = min( v_EF );
                    for idd = 1:3
                        if v_EF(idd) ~= EF0 && v_EF(idd) ~= EF2
                            EF1 = v_EF(idd);
                        end
                    end
                elseif n1*n0 < 0
                    EFa = EF1;
                    EFb = EF0;
                    EFc = (EF1 + EF0)/2;
                    v_EF = [EFa, EFb, EFc];
                    EF2 = max( v_EF ); 
                    EF0 = min( v_EF );
                    for idd = 1:3
                        if v_EF(idd) ~= EF0 && v_EF(idd) ~= EF2
                            EF1 = v_EF(idd);
                        end
                    end
                end

                n0 = sd/(2*pi)^3*dVk*sum(sum(sum(sum(1./(exp((Ek(:,:,:,bands_transp(1):bands_transp(size(bands_transp,2)))-EF0)./(kB*T_array(id_T)/q0))+1))))) - N_imp_temp; % in m^-3
                n1 = sd/(2*pi)^3*dVk*sum(sum(sum(sum(1./(exp((Ek(:,:,:,bands_transp(1):bands_transp(size(bands_transp,2)))-EF1)./(kB*T_array(id_T)/q0))+1))))) - N_imp_temp; % in m^-3
                n2 = sd/(2*pi)^3*dVk*sum(sum(sum(sum(1./(exp((Ek(:,:,:,bands_transp(1):bands_transp(size(bands_transp,2)))-EF2)./(kB*T_array(id_T)/q0))+1))))) - N_imp_temp; % in m^-3

                Delta_N = n1 / N_imp_temp;

            end
           EF_matrix(id_EF,id_T) = EF1;
           N_imp_matrix(id_EF,id_T) = N_imp_temp + n1;
           else
             N_imp_matrix(id_EF,id_T) = N_imp_temp;
         end        

     end
         
end
Nz = ~N_imp_matrix;
N_imp_matrix(Nz) = 1e6;

end