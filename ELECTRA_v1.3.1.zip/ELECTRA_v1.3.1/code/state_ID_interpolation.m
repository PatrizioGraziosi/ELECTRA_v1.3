function state_ID_interp = state_ID_interpolation(state_ID, id_E, id_n)

state_ID_En = state_ID(id_E,id_n);
state_ID_interp = struct();
 
        kx = state_ID_En.kx;
        ky = state_ID_En.ky;
        kz = state_ID_En.kz;
        knorm = state_ID_En.knorm;
        vx = state_ID_En.v_x;
        vy = state_ID_En.v_y;
        vz = state_ID_En.v_z;
        V = state_ID_En.V;
        DOS = state_ID_En.DOS;
        dS = state_ID_En.surface;

        if not(size(vx,2)) == 0   % the state is not empty
            
            k_points_number = size(vx,2);
            
            kx_interp = [];
            ky_interp = [];
            kz_interp = [];
            
            ptCloud = pointCloud( [kx', ky', kz'  ] ) ;
            
            for ik = 1 : k_points_number
                
                [indexes,dists] = findNearestNeighbors(ptCloud,[kx(ik),ky(ik),kz(ik)],6) ;
                
                kx_temp = (kx(indexes)-kx(ik))/3 + kx(ik);
                ky_temp = (ky(indexes)-ky(ik))/3 + ky(ik);
                F = scatteredInterpolant( kx', ky', kz', 'natural'); % interpolant for kz
                kz_temp = F( kx_temp, ky_temp);
                
                kx_interp = [kx_interp, kx_temp];
                ky_interp = [ky_interp, ky_temp];
                kz_interp = [kz_interp, kz_temp];
                
            end
            
            F = scatteredInterpolant( kx', ky', kz', vx', 'natural');
            vx_interp = F( kx_interp, ky_interp, kz_interp);
            F = scatteredInterpolant( kx', ky', kz', vy', 'natural' );
            vy_interp = F( kx_interp, ky_interp, kz_interp);
            F = scatteredInterpolant( kx', ky', kz', vz', 'natural' );
            vz_interp = F( kx_interp, ky_interp, kz_interp);
            F = scatteredInterpolant( kx', ky', kz', V', 'natural' );
            V_interp = F( kx_interp, ky_interp, kz_interp);
            F = scatteredInterpolant( kx', ky', kz', DOS', 'natural' );
            DOS_interp = F( kx_interp, ky_interp, kz_interp);
            F = scatteredInterpolant( kx', ky', kz', dS', 'natural' );
            dS_interp = F( kx_interp, ky_interp, kz_interp);
            
%             vx_interp = interp3(kx, ky, kz, vx, kx_interp, ky_interp, kz_interp, 'makima');
%             vy_interp = interp3(kx, ky, kz, vy, kx_interp, ky_interp, kz_interp, 'makima');
%             vz_interp = interp3(kx, ky, kz, vz, kx_interp, ky_interp, kz_interp, 'makima');
%             V_interp = interp3(kx, ky, kz, V, kx_interp, ky_interp, kz_interp, 'makima');
%             DOS_interp = interp3(kx, ky, kz, DOS, kx_interp, ky_interp, kz_interp, 'makima');
%             dS_interp = interp3(kx, ky, kz, dS, kx_interp, ky_interp, kz_interp, 'makima');
            
            vx = [vx, vx_interp];
            vy = [vy, vy_interp];
            vz = [vz, vz_interp];            
            V = [V, V_interp];
            DOS = [DOS, DOS_interp];
            dS = [dS, dS_interp];
            kx = [kx, kx_interp];
            ky = [ky, ky_interp];
            kz = [kz, kz_interp];
            knorm = [knorm, (kx_interp.^2 + ky_interp.^2 + kz_interp.^2)];
            
            state_ID_interp.kx = kx;
            state_ID_interp.ky = ky;
            state_ID_interp.kz = kz;
            state_ID_interp.knorm = knorm;
            state_ID_interp.v_x = vx;
            state_ID_interp.v_y = vy;
            state_ID_interp.v_z = vz;
            state_ID_interp.V = V;
            state_ID_interp.DOS = DOS;
            state_ID_interp.surface = dS;
            state_ID_interp.E = state_ID_En.E;
            
        else
            state_ID_interp = state_ID_En;
        end








end